// Dans web/actions/admin_login_process.php

<?php
require_once '../config/config.php';
require_once '../utils/database.php';
require_once '../utils/helpers.php';
require_once '../utils/mailer.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
       
    $stmt = $conn->prepare("SELECT id, email, password FROM users WHERE email = ? AND role = 'admin'");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        
        if (password_verify($password, $user['password'])) {
            
            $code = rand(100000, 999999);
            
            
            $expiry = date('Y-m-d H:i:s', strtotime('+15 minutes'));
            $stmtCode = $conn->prepare("INSERT INTO admin_auth_codes (user_id, code, expiry_date) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE code = ?, expiry_date = ?");
            $stmtCode->bind_param("issss", $user['id'], $code, $expiry, $code, $expiry);
            $stmtCode->execute();
            
            
            $subject = "Code d'authentification BusinessCare";
            $body = '
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <title>Code d\'authentification</title>
            </head>
            <body>
                <div style="max-width: 600px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif;">
                    <div style="background-color: #4CAF50; color: white; padding: 10px; text-align: center;">
                        <h1>BusinessCare</h1>
                    </div>
                    <div style="padding: 20px; background-color: #f9f9f9;">
                        <h2>Code d\'authentification</h2>
                        <p>Bonjour,</p>
                        <p>Voici votre code d\'authentification pour accéder à l\'espace administrateur :</p>
                        <div style="background-color: #eee; padding: 15px; text-align: center; font-size: 24px; font-weight: bold; letter-spacing: 5px; margin: 20px 0;">
                            ' . $code . '
                        </div>
                        <p>Ce code est valable pendant 15 minutes.</p>
                        <p>Si vous n\'avez pas demandé ce code, veuillez ignorer cet email.</p>
                    </div>
                    <div style="padding: 10px; text-align: center; font-size: 12px; color: #777;">
                        <p>© ' . date('Y') . ' BusinessCare. Tous droits réservés.</p>
                    </div>
                </div>
            </body>
            </html>
            ';
            $stmt->close();
            
            if (sendEmail($user['email'], $subject, $body)) {
                
                session_start();
                $_SESSION['admin_auth_id'] = $user['id'];
                
                
                header("Location: ../back_office/verify_code.php");
                exit;
            } else {
                
                header("Location: ../pages/login.php?error=email_error");
                exit;
            }
        } else {
            
            header("Location: ../pages/login.php?error=invalid_credentials");
            exit;
        }
    } else {
    
        header("Location: ../pages/login.php?error=invalid_credentials");
        exit;
    }
}
?>