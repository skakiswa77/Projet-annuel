<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$webPath = dirname(__DIR__);


require_once $webPath . '/vendor/phpmailer/phpmailer/src/Exception.php';
require_once $webPath . '/vendor/phpmailer/phpmailer/src/PHPMailer.php';
require_once $webPath . '/vendor/phpmailer/phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

function sendContactEmail($to, $subject, $body, $replyToEmail = '', $replyToName = '') {
    $mail = new PHPMailer(true);
    
    try {

        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'businesscareams@gmail.com';
        $mail->Password   = 'jtew sppg slcq xpqr'; 
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;
        $mail->CharSet    = 'UTF-8';
        
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ];
        
        $mail->Timeout = 60; 
        

        $mail->setFrom('businesscareams@gmail.com', 'Business Care');
        $mail->addAddress($to);
        
        if ($replyToEmail) {
            $mail->addReplyTo($replyToEmail, $replyToName);
        }
        
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;
        $mail->AltBody = strip_tags($body);
        
        $mail->SMTPAutoTLS = false;
        

        return $mail->send();
    } catch (Exception $e) {
        error_log("Erreur d'envoi d'email: " . $e->getMessage());
        return false;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_SPECIAL_CHARS);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_SPECIAL_CHARS);
    $company = filter_input(INPUT_POST, 'company', FILTER_SANITIZE_SPECIAL_CHARS);
    $subject = filter_input(INPUT_POST, 'subject', FILTER_SANITIZE_SPECIAL_CHARS);
    $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_SPECIAL_CHARS);
    $privacy = isset($_POST['privacy']) ? true : false;
    
    if (!$name || !$email || !$subject || !$message || !$privacy) {
        header('Location: ../index.php?page=contact&error=missing_fields');
        exit;
    }
    
    $emailSubject = 'Formulaire de contact: ' . $subject;
    $emailBody = "
    <html>
    <head>
        <title>Nouveau message de contact</title>
    </head>
    <body>
        <h2>Nouveau message depuis le formulaire de contact</h2>
        <p><strong>Nom:</strong> $name</p>
        <p><strong>Email:</strong> $email</p>
        <p><strong>Téléphone:</strong> $phone</p>
        <p><strong>Entreprise:</strong> $company</p>
        <p><strong>Sujet:</strong> $subject</p>
        <p><strong>Message:</strong></p>
        <p>$message</p>
    </body>
    </html>
    ";
    
    $emailSent = sendContactEmail('businesscareams@gmail.com', $emailSubject, $emailBody, $email, $name);
    
    if (!$emailSent) {
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=utf-8\r\n";
        $headers .= "From: Business Care <businesscareams@gmail.com>\r\n";
        $headers .= "Reply-To: $name <$email>\r\n";
        
        $emailSent = mail('businesscareams@gmail.com', $emailSubject, $emailBody, $headers);
    }
    
    if ($emailSent) {
        header('Location: ../index.php?page=contact&success=message_sent');
    } else {
        error_log("Echec de l'envoi du formulaire de contact de $email ($name)");
        header('Location: ../index.php?page=contact&success=message_sent');
    }
    exit;
} else {
    header('Location: ../index.php?page=contact');
    exit;
}
?>