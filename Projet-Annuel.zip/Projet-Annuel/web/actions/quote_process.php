<?php
session_start();

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../vendor/fpdf/fpdf.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $companyName = trim($_POST['company_name'] ?? '');
    $companyEmail = trim($_POST['company_email'] ?? '');
    $companyPhone = trim($_POST['company_phone'] ?? '');
    $companyAddress = trim($_POST['company_address'] ?? '');
    $contactName = trim($_POST['contact_name'] ?? '');
    $contactPosition = trim($_POST['contact_position'] ?? '');
    $employeesCount = (int)($_POST['employees_count'] ?? 0);
    $plan = trim($_POST['plan'] ?? 'starter');
    $options = $_POST['options'] ?? [];
    $comments = trim($_POST['comments'] ?? '');

    $planPrices = [
        'starter' => 100,
        'basic' => 150,
        'premium' => 180
    ];
    
    $optionPrices = [
        'extra_events' => 500,
        'extra_appointments' => 300,
        'workshops' => 800,
        'custom' => 'Sur devis'
    ];

    $planName = [
        'starter' => 'Formule Starter',
        'basic' => 'Formule Basic',
        'premium' => 'Formule Premium'
    ];

    $optionNames = [
        'extra_events' => 'Événements supplémentaires',
        'extra_appointments' => 'Rendez-vous médicaux supplémentaires',
        'workshops' => 'Ateliers bien-être sur site',
        'custom' => 'Programme personnalisé'
    ];

    $pricePerEmployee = $planPrices[$plan] ?? 100;
    $subscriptionCost = $employeesCount * $pricePerEmployee;
    
    $monthlyOptionsCost = 0;
    foreach ($options as $option) {
        if ($option != 'custom' && isset($optionPrices[$option])) {
            $monthlyOptionsCost += $optionPrices[$option];
        }
    }
    
    $annualOptionsCost = $monthlyOptionsCost * 12;
    $totalCost = $subscriptionCost + $annualOptionsCost;
    
    class PDF extends FPDF {
        function Header() {

            $logoPath = __DIR__ . '/../assets/images/BCLogo.png';
            
            if (file_exists($logoPath)) {
                $this->Image($logoPath, 10, 10, 30);
            }

            $this->SetFont('Arial', 'B', 15);
            
            $this->Cell(0, 10, 'DEVIS - BUSINESS CARE', 0, 1, 'C');
            
            $this->SetFont('Arial', '', 10);
            $this->Cell(0, 10, 'Date: ' . date('d/m/Y'), 0, 1, 'R');
            
            $this->Ln(5);
        }
        
        function Footer() {

            $this->SetY(-15);
 
            $this->SetFont('Arial', 'I', 8);

            $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
        }
    }

    $pdf = new PDF();
    $pdf->AddPage();
    
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Informations de l\'entreprise', 0, 1, 'L');
    $pdf->SetFont('Arial', '', 11);
    $pdf->Cell(60, 7, 'Nom de l\'entreprise:', 0, 0);
    $pdf->Cell(0, 7, $companyName, 0, 1);
    $pdf->Cell(60, 7, 'Email:', 0, 0);
    $pdf->Cell(0, 7, $companyEmail, 0, 1);
    $pdf->Cell(60, 7, 'Telephone:', 0, 0);
    $pdf->Cell(0, 7, $companyPhone, 0, 1);
    $pdf->Cell(60, 7, 'Adresse:', 0, 0);
    $pdf->Cell(0, 7, $companyAddress, 0, 1);
    $pdf->Cell(60, 7, 'Contact:', 0, 0);
    $pdf->Cell(0, 7, $contactName . ($contactPosition ? ' - ' . $contactPosition : ''), 0, 1);
    $pdf->Cell(60, 7, 'Nombre de salaries:', 0, 0);
    $pdf->Cell(0, 7, $employeesCount, 0, 1);
    $pdf->Ln(5);
    
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Formule sélectionnee', 0, 1, 'L');
    $pdf->SetFont('Arial', '', 11);
    $pdf->Cell(0, 7, $planName[$plan] . ' - ' . $pricePerEmployee . '€ par salarie par an', 0, 1);
    
    $pdf->SetFont('Arial', 'I', 10);
    if ($plan == 'starter') {
        $pdf->MultiCell(0, 5, '- Jusqu\'à 30 salaries
- 2 activites par mois
- 1 RDV medical par mois
- 6 questions au chatbot
- Accès illimite aux fiches pratiques');
    } elseif ($plan == 'basic') {
        $pdf->MultiCell(0, 5, '- Jusqu\'à 250 salaries
- 3 activites par mois
- 2 RDV médicaux par mois
- 20 questions au chatbot
- Conseils hebdomadaires');
    } elseif ($plan == 'premium') {
        $pdf->MultiCell(0, 5, '- À partir de 251 salaries
- 4 activites par mois
- 3 RDV medicaux par mois
- Questions illimitees au chatbot
- Conseils personnalises');
    }
    $pdf->Ln(5);
    

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Options additionnelles', 0, 1, 'L');
    $pdf->SetFont('Arial', '', 11);
    
    if (empty($options)) {
        $pdf->Cell(0, 7, 'Aucune option sélectionnee', 0, 1);
    } else {
        foreach ($options as $option) {
            if (isset($optionNames[$option])) {
                if ($option == 'custom') {
                    $pdf->Cell(0, 7, $optionNames[$option] . ' - Sur devis', 0, 1);
                } else {
                    $pdf->Cell(0, 7, $optionNames[$option] . ' - ' . $optionPrices[$option] . '€ par mois', 0, 1);
                }
            }
        }
    }
    $pdf->Ln(5);
    
    if (!empty($comments)) {
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, 'Commentaires', 0, 1, 'L');
        $pdf->SetFont('Arial', '', 11);
        $pdf->MultiCell(0, 5, $comments);
        $pdf->Ln(5);
    }
    
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Details du calcul', 0, 1, 'L');
    $pdf->SetFont('Arial', '', 11);
    
    $pdf->Cell(140, 7, 'Abonnement annuel (' . $employeesCount . ' salaries x ' . $pricePerEmployee . '€)', 0, 0);
    $pdf->Cell(0, 7, number_format($subscriptionCost, 2, ',', ' ') . ' €', 0, 1, 'R');
    
    $pdf->Cell(140, 7, 'Options (par mois)', 0, 0);
    $pdf->Cell(0, 7, number_format($monthlyOptionsCost, 2, ',', ' ') . ' €', 0, 1, 'R');
    
    $pdf->Cell(140, 7, 'Options (par an)', 0, 0);
    $pdf->Cell(0, 7, number_format($annualOptionsCost, 2, ',', ' ') . ' €', 0, 1, 'R');
    
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(140, 10, 'Total annuel estime', 'T', 0);
    $pdf->Cell(0, 10, number_format($totalCost, 2, ',', ' ') . ' €', 'T', 1, 'R');
    
    $pdf->SetFont('Arial', 'I', 8);
    $pdf->Cell(0, 5, '* Ce devis est une estimation et pourra être ajuste selon vos besoins exacts.', 0, 1);
    $pdf->Cell(0, 5, '* Prix HT, TVA applicable au taux en vigueur.', 0, 1);
    $pdf->Ln(5);
    

    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(0, 10, 'Pour toute question concernant ce devis, veuillez nous contacter :', 0, 1, 'L');
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(0, 5, 'Email: businesscareams@gmail.com', 0, 1);
    $pdf->Cell(0, 5, 'Téléphone: 07 68 16 39 48', 0, 1);
    $pdf->Cell(0, 5, 'Site web: www.businesscare.fr', 0, 1);
    

    $pdf->Ln(5);
    $pdf->SetFont('Arial', 'I', 9);
    $pdf->Cell(0, 5, 'Ce devis est valable 30 jours à compter de la date d\'emission.', 0, 1);
    

    $pdfFilename = 'Devis_BusinessCare_' . date('Y-m-d') . '_' . uniqid() . '.pdf';
    

    try {
        $db = Database::getInstance();
        
        try {
            $db->query("SELECT 1 FROM quotes LIMIT 1");
        } catch (Exception $e) {
            $db->execute("
                CREATE TABLE IF NOT EXISTS quotes (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    company_name VARCHAR(255) NOT NULL,
                    company_email VARCHAR(255) NOT NULL,
                    company_phone VARCHAR(50),
                    company_address VARCHAR(255),
                    contact_name VARCHAR(255),
                    contact_position VARCHAR(255),
                    employees_count INT NOT NULL,
                    plan VARCHAR(50) NOT NULL,
                    comments TEXT,
                    status VARCHAR(20) DEFAULT 'pending',
                    pdf_filename VARCHAR(255),
                    created_at DATETIME NOT NULL,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            ");
        }
        
        try {
            $db->query("SELECT 1 FROM quote_options LIMIT 1");
        } catch (Exception $e) {
            $db->execute("
                CREATE TABLE IF NOT EXISTS quote_options (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    quote_id INT NOT NULL,
                    option_name VARCHAR(100) NOT NULL,
                    created_at DATETIME NOT NULL,
                    FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE CASCADE
                )
            ");
        }
        
        $quoteId = $db->insert('quotes', [
            'company_name' => $companyName,
            'company_email' => $companyEmail,
            'company_phone' => $companyPhone,
            'company_address' => $companyAddress,
            'contact_name' => $contactName,
            'contact_position' => $contactPosition,
            'employees_count' => $employeesCount,
            'plan' => $plan,
            'comments' => $comments,
            'status' => 'pending',
            'pdf_filename' => $pdfFilename,
            'created_at' => date('Y-m-d H:i:s')
        ]);
        
        foreach ($options as $option) {
            $db->insert('quote_options', [
                'quote_id' => $quoteId,
                'option_name' => $option,
                'created_at' => date('Y-m-d H:i:s')
            ]);
        }
        
        $pdf->Output('D', $pdfFilename);
        exit;
        
    } catch (Exception $e) {
        error_log("Erreur lors de la génération du devis: " . $e->getMessage());
        
        $pdf->Output('D', $pdfFilename);
        exit;
    }
} else {
    header("Location: " . (defined('APP_URL') ? APP_URL : '') . "/index.php?page=quote");
    exit;
}