<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'employee') {
    setAlert('Accès non autorisé.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$db = Database::getInstance();

try {
    $user = $db->query(
        "SELECT u.*, c.name as company_name 
         FROM users u
         LEFT JOIN companies c ON u.company_id = c.id
         WHERE u.id = ? LIMIT 1",
        [$_SESSION['user_id']],
        true
    );

    if (!$user) {
        throw new Exception("Utilisateur non trouvé");
    }
} catch (Exception $e) {
    $user = [
        'id' => $_SESSION['user_id'],
        'first_name' => $_SESSION['user_name'] ?? 'Employé',
        'last_name' => '',
        'profile_picture' => '',
        'company_name' => 'Entreprise'
    ];
}


try {

    $upcomingAppointmentsCount = $db->query(
        "SELECT COUNT(*) as count FROM medical_appointments 
         WHERE user_id = ? AND appointment_datetime > NOW() AND status != 'cancelled'",
        [$_SESSION['user_id']],
        true
    );
    $appointmentsCount = $upcomingAppointmentsCount['count'] ?? 0;

    $upcomingEventsCount = $db->query(
        "SELECT COUNT(*) as count FROM event_registrations er
         JOIN events e ON er.event_id = e.id
         WHERE er.user_id = ? AND e.start_datetime > NOW() AND er.status != 'cancelled'",
        [$_SESSION['user_id']],
        true
    );
    $eventsCount = $upcomingEventsCount['count'] ?? 0;

    $nfcAccessCount = $db->query(
        "SELECT COUNT(*) as count FROM nfc_cards nc
         JOIN nfc_access_logs nal ON nc.id = nal.card_id
         WHERE nc.user_id = ? AND DATE(nal.access_datetime) = CURDATE()",
        [$_SESSION['user_id']],
        true
    );
    $nfcCount = $nfcAccessCount['count'] ?? 0;

    $wellnessCount = $db->query(
        "SELECT COUNT(*) as count FROM events e
         JOIN event_types et ON e.event_type_id = et.id
         JOIN companies c ON c.id = ?
         JOIN users u ON u.company_id = c.id
         WHERE e.start_datetime > NOW() AND et.is_medical = 0 AND u.id = ?
         GROUP BY u.id",
        [$user['company_id'], $_SESSION['user_id']],
        true
    );
    $wellnessActivities = $wellnessCount['count'] ?? 0;
} catch (Exception $e) {
    $appointmentsCount = 0;
    $eventsCount = 0;
    $nfcCount = 0;
    $wellnessActivities = 0;
}

$dashboardStats = [
    'stat1' => ['value' => $appointmentsCount, 'label' => 'Rendez-vous à venir', 'icon' => 'calendar-check'],
    'stat2' => ['value' => $eventsCount, 'label' => 'Événements à venir', 'icon' => 'calendar-day'],
    'stat3' => ['value' => $nfcCount, 'label' => 'Accès aujourd\'hui', 'icon' => 'id-card'],
    'stat4' => ['value' => $wellnessActivities, 'label' => 'Activités disponibles', 'icon' => 'spa']
];

try {
    $upcomingAppointments = $db->query(
        "SELECT a.*, u.first_name as provider_first_name, u.last_name as provider_last_name, 
                ps.name as specialization
         FROM medical_appointments a
         JOIN provider_profiles pp ON a.provider_id = pp.id
         JOIN users u ON pp.user_id = u.id
         JOIN provider_specializations ps ON pp.specialization_id = ps.id
         WHERE a.user_id = ? AND a.appointment_datetime > NOW() AND a.status != 'cancelled'
         ORDER BY a.appointment_datetime ASC
         LIMIT 5",
        [$_SESSION['user_id']]
    );
} catch (Exception $e) {
    $upcomingAppointments = [];
}

try {
    $upcomingEvents = $db->query(
        "SELECT e.*, et.name as event_type_name, er.status as registration_status
         FROM events e
         JOIN event_registrations er ON e.id = er.event_id
         JOIN event_types et ON e.event_type_id = et.id
         WHERE er.user_id = ? AND e.start_datetime > NOW()
         ORDER BY e.start_datetime ASC
         LIMIT 3",
        [$_SESSION['user_id']]
    );
} catch (Exception $e) {
    $upcomingEvents = [];
}

try {
    $latestActivities = $db->query(
        "SELECT 'event' as type, e.title as name, e.start_datetime as date, et.name as category
         FROM events e
         JOIN event_registrations er ON e.id = er.event_id
         JOIN event_types et ON e.event_type_id = et.id
         WHERE er.user_id = ? AND er.status = 'attended'
         UNION
         SELECT 'appointment' as type, CONCAT(u.first_name, ' ', u.last_name) as name, 
                a.appointment_datetime as date, ps.name as category
         FROM medical_appointments a
         JOIN provider_profiles pp ON a.provider_id = pp.id
         JOIN users u ON pp.user_id = u.id
         JOIN provider_specializations ps ON pp.specialization_id = ps.id
         WHERE a.user_id = ? AND a.status = 'completed'
         ORDER BY date DESC
         LIMIT 5",
        [$_SESSION['user_id'], $_SESSION['user_id']]
    );
} catch (Exception $e) {
    $latestActivities = [];
}

$pageTitle = "Tableau de bord";
$spaceName = "Espace Employé";
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> | Business Care</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>

    <div class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <i class="fas fa-heartbeat"></i>
            <span>Business Care</span>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="active">
                <i class="fas fa-tachometer-alt"></i>
                <span>Tableau de bord</span>
            </a>
            <a href="appointments.php">
                <i class="fas fa-calendar-check"></i>
                <span>Rendez-vous</span>
            </a>
            <a href="events.php">
                <i class="fas fa-calendar-day"></i>
                <span>Événements</span>
            </a>
            <a href="nfc-card.php">
                <i class="fas fa-id-card"></i>
                <span>Carte NFC</span>
            </a>
            <a href="profile.php">
                <i class="fas fa-user"></i>
                <span>Profil</span>
            </a>
            <a href="notifications.php">
                <i class="fas fa-bell"></i>
                <span>Notifications</span>
            </a>
            <a href="messages.php">
                <i class="fas fa-envelope"></i>
                <span>Messages</span>
            </a>
            <a href="../logout.php">
                <i class="fas fa-sign-out-alt"></i>
                <span>Déconnexion</span>
            </a>
        </div>
    </div>

    <div class="main-content" id="mainContent">

        <div class="card mb-4">
            <div class="card-body d-flex justify-content-between align-items-center py-3">
                <div>
                    <button class="btn btn-link text-primary p-0 me-2" id="sidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <span class="h4 mb-0 d-inline-block"><?= $spaceName ?></span>
                </div>
                <div class="d-flex align-items-center">
                    <div class="me-3 text-end">
                        <div class="fw-bold"><?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></div>
                        <small class="text-muted"><?= htmlspecialchars($user['company_name']) ?></small>
                    </div>
                    <img src="<?= $user['profile_picture'] ?: 'https://via.placeholder.com/40' ?>" 
                         alt="<?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?>"
                         class="rounded-circle" width="40" height="40">
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <h2 class="mb-0">Bienvenue, <?= htmlspecialchars($user['first_name']) ?> !</h2>
                <p class="text-muted">
                    Accédez à vos services de bien-être et consultez vos prochains rendez-vous et événements.
                </p>
            </div>
        </div>


        <div class="row">
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <div class="stat-icon bg-primary-soft mx-auto">
                            <i class="fas fa-<?= $dashboardStats['stat1']['icon'] ?>"></i>
                        </div>
                        <div class="h2 mt-2"><?= $dashboardStats['stat1']['value'] ?></div>
                        <div class="text-muted"><?= $dashboardStats['stat1']['label'] ?></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <div class="stat-icon bg-success-soft mx-auto">
                            <i class="fas fa-<?= $dashboardStats['stat2']['icon'] ?>"></i>
                        </div>
                        <div class="h2 mt-2"><?= $dashboardStats['stat2']['value'] ?></div>
                        <div class="text-muted"><?= $dashboardStats['stat2']['label'] ?></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <div class="stat-icon bg-info-soft mx-auto">
                            <i class="fas fa-<?= $dashboardStats['stat3']['icon'] ?>"></i>
                        </div>
                        <div class="h2 mt-2"><?= $dashboardStats['stat3']['value'] ?></div>
                        <div class="text-muted"><?= $dashboardStats['stat3']['label'] ?></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <div class="stat-icon bg-warning-soft mx-auto">
                            <i class="fas fa-<?= $dashboardStats['stat4']['icon'] ?>"></i>
                        </div>
                        <div class="h2 mt-2"><?= $dashboardStats['stat4']['value'] ?></div>
                        <div class="text-muted"><?= $dashboardStats['stat4']['label'] ?></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-8">

                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Prochains rendez-vous</h5>
                        <a href="appointments.php" class="btn btn-sm btn-primary">Voir tout</a>
                    </div>
                    <div class="card-body">
                        <?php if (empty($upcomingAppointments)): ?>
                            <div class="text-center py-3">
                                <i class="fas fa-calendar-check fa-3x text-muted mb-3"></i>
                                <p>Vous n'avez aucun rendez-vous à venir pour le moment.</p>
                                <a href="appointments.php?action=new" class="btn btn-sm btn-outline-primary">Prendre rendez-vous</a>
                            </div>
                        <?php else: ?>
                            <div class="list-group list-group-flush">
                                <?php foreach ($upcomingAppointments as $appointment): ?>
                                    <div class="calendar-item">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <div class="calendar-date">
                                                    <?= date('d/m/Y H:i', strtotime($appointment['appointment_datetime'])) ?>
                                                </div>
                                                <div class="calendar-title">
                                                    <?= htmlspecialchars($appointment['provider_first_name'] . ' ' . $appointment['provider_last_name']) ?>
                                                </div>
                                                <small class="text-muted"><?= htmlspecialchars($appointment['specialization']) ?></small>
                                            </div>
                                            <span class="badge bg-<?= $appointment['status'] === 'pending' ? 'warning' : ($appointment['status'] === 'confirmed' ? 'success' : 'primary') ?>">
                                                <?= $appointment['status'] === 'pending' ? 'En attente' : ($appointment['status'] === 'confirmed' ? 'Confirmé' : 'Planifié') ?>
                                            </span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>


                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Événements à venir</h5>
                        <a href="events.php" class="btn btn-sm btn-primary">Voir tout</a>
                    </div>
                    <div class="card-body">
                        <?php if (empty($upcomingEvents)): ?>
                            <div class="text-center py-3">
                                <i class="fas fa-calendar-alt fa-3x text-muted mb-3"></i>
                                <p>Vous n'êtes inscrit à aucun événement pour le moment.</p>
                                <a href="events.php?action=browse" class="btn btn-sm btn-outline-primary">Explorer les événements</a>
                            </div>
                        <?php else: ?>
                            <div class="list-group list-group-flush">
                                <?php foreach ($upcomingEvents as $event): ?>
                                    <div class="calendar-item">
                                        <div class="calendar-date">
                                            <?= date('d/m/Y', strtotime($event['start_datetime'])) ?>
                                            <?= date('H:i', strtotime($event['start_datetime'])) ?> -
                                            <?= date('H:i', strtotime($event['end_datetime'])) ?>
                                        </div>
                                        <div class="calendar-title"><?= htmlspecialchars($event['title']) ?></div>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <small class="text-muted"><?= htmlspecialchars($event['event_type_name'] ?? 'Type non défini') ?></small>
                                            <span class="badge bg-<?= $event['registration_status'] === 'pending' ? 'warning' : ($event['registration_status'] === 'confirmed' ? 'success' : 'primary') ?>">
                                                <?= $event['registration_status'] === 'pending' ? 'En attente' : ($event['registration_status'] === 'confirmed' ? 'Confirmé' : 'Inscrit') ?>
                                            </span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">

                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Ma carte NFC</h5>
                    </div>
                    <div class="card-body">
                        <?php

                        $hasNFCCard = false;
                        try {
                            $nfcCard = $db->query(
                                "SELECT * FROM nfc_cards WHERE user_id = ? AND is_active = 1 LIMIT 1",
                                [$_SESSION['user_id']],
                                true
                            );
                            $hasNFCCard = !empty($nfcCard);
                        } catch (Exception $e) {
                            $hasNFCCard = false;
                        }
                        ?>
                        
                        <?php if ($hasNFCCard): ?>
                            <div class="text-center mb-4">
                                <i class="fas fa-id-card fa-4x text-primary mb-3"></i>
                                <h5>Carte NFC activée</h5>
                                <p class="text-muted">Identifiant : <?= substr($nfcCard['card_uid'], 0, 4) . '...' . substr($nfcCard['card_uid'], -4) ?></p>
                                <p>Date d'émission : <?= date('d/m/Y', strtotime($nfcCard['issued_date'])) ?></p>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-3">
                                <i class="fas fa-id-card fa-3x text-muted mb-3"></i>
                                <p>Vous n'avez pas encore de carte NFC active.</p>
                                <a href="nfc-card.php?action=request" class="btn btn-sm btn-outline-primary">Demander une carte</a>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer text-center">
                        <a href="nfc-card.php" class="text-decoration-none">Gérer ma carte NFC</a>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Mes dernières activités</h5>
                    </div>
                    <div class="card-body p-0">
                        <?php if (empty($latestActivities)): ?>
                            <div class="text-center py-3">
                                <i class="fas fa-history fa-3x text-muted mb-3"></i>
                                <p>Aucune activité récente.</p>
                            </div>
                        <?php else: ?>
                            <div class="list-group list-group-flush">
                                <?php foreach ($latestActivities as $activity): ?>
                                    <div class="list-group-item">
                                        <div class="d-flex align-items-center">
                                            <div class="flex-shrink-0 me-3">
                                                <div class="avatar bg-<?= $activity['type'] === 'event' ? 'info' : 'success' ?>-soft text-<?= $activity['type'] === 'event' ? 'info' : 'success' ?> rounded-circle p-2">
                                                    <i class="fas fa-<?= $activity['type'] === 'event' ? 'calendar-day' : 'user-md' ?>"></i>
                                                </div>
                                            </div>
                                            <div class="flex-grow-1">
                                                <p class="mb-1"><?= htmlspecialchars($activity['name']) ?></p>
                                                <div class="d-flex justify-content-between">
                                                    <small class="text-muted"><?= htmlspecialchars($activity['category']) ?></small>
                                                    <small><?= date('d/m/Y', strtotime($activity['date'])) ?></small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Actions rapides</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <a href="appointments.php?action=new" class="btn btn-primary">
                                <i class="fas fa-calendar-plus me-2"></i>Prendre rendez-vous
                            </a>
                            <a href="events.php?action=browse" class="btn btn-outline-primary">
                                <i class="fas fa-calendar-day me-2"></i>Explorer les événements
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('mainContent');
            const sidebarToggle = document.getElementById('sidebarToggle');
            
            function toggleSidebar() {
                sidebar.classList.toggle('expanded');
                mainContent.classList.toggle('contracted');
            }

            sidebarToggle.addEventListener('click', toggleSidebar);
            
            <?php if (isset($_SESSION['alert'])): ?>
                const alertDiv = document.createElement('div');
                alertDiv.className = 'alert alert-<?= $_SESSION['alert']['type'] ?> alert-dismissible fade show';
                alertDiv.setAttribute('role', 'alert');
                alertDiv.innerHTML = `
                    <?= $_SESSION['alert']['message'] ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                `;
                
                mainContent.insertBefore(alertDiv, mainContent.firstChild);
                
                setTimeout(function() {
                    const bsAlert = new bootstrap.Alert(alertDiv);
                    bsAlert.close();
                }, 5000);
                
                <?php unset($_SESSION['alert']); ?>
            <?php endif; ?>
        });
    </script>
</body>
</html>