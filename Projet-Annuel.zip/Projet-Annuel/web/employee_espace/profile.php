<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'employee') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que employee.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}
$employee_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT u.*, c.name as company_name
    FROM users u
    LEFT JOIN companies c ON u.company_id = c.id
    WHERE u.id = :user_id
");
$stmt->execute(['user_id' => $employee_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("
    SELECT * FROM notification_preferences
    WHERE user_id = :user_id
");
$stmt->execute(['user_id' => $employee_id]);
$notification_prefs = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $postal_code = $_POST['postal_code'];
    $city = $_POST['city'];
    
    try {
        $stmt = $pdo->prepare("
            UPDATE users 
            SET phone = :phone, address = :address, postal_code = :postal_code, city = :city
            WHERE id = :user_id
        ");
        
        $stmt->execute([
            'phone' => $phone,
            'address' => $address,
            'postal_code' => $postal_code,
            'city' => $city,
            'user_id' => $employee_id
        ]);
        
        $success_message = "Votre profil a été mis à jour avec succès.";
        
        $user['phone'] = $phone;
        $user['address'] = $address;
        $user['postal_code'] = $postal_code;
        $user['city'] = $city;
    } catch (PDOException $e) {
        $error_message = "Une erreur est survenue lors de la mise à jour du profil: " . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_notifications'])) {
    $email_events = isset($_POST['email_events']) ? 1 : 0;
    $email_appointments = isset($_POST['email_appointments']) ? 1 : 0;
    $email_community = isset($_POST['email_community']) ? 1 : 0;
    $email_marketing = isset($_POST['email_marketing']) ? 1 : 0;
    $push_events = isset($_POST['push_events']) ? 1 : 0;
    $push_appointments = isset($_POST['push_appointments']) ? 1 : 0;
    $push_community = isset($_POST['push_community']) ? 1 : 0;
    $push_marketing = isset($_POST['push_marketing']) ? 1 : 0;
    
    try {
        $stmt = $pdo->prepare("
            UPDATE notification_preferences 
            SET email_events = :email_events, 
                email_appointments = :email_appointments,
                email_community = :email_community,
                email_marketing = :email_marketing,
                push_events = :push_events,
                push_appointments = :push_appointments,
                push_community = :push_community,
                push_marketing = :push_marketing,
                updated_at = NOW()
            WHERE user_id = :user_id
        ");
        
        $stmt->execute([
            'email_events' => $email_events,
            'email_appointments' => $email_appointments,
            'email_community' => $email_community,
            'email_marketing' => $email_marketing,
            'push_events' => $push_events,
            'push_appointments' => $push_appointments,
            'push_community' => $push_community,
            'push_marketing' => $push_marketing,
            'user_id' => $employee_id
        ]);
        
        $notification_success_message = "Vos préférences de notification ont été mises à jour avec succès.";
        
        $notification_prefs['email_events'] = $email_events;
        $notification_prefs['email_appointments'] = $email_appointments;
        $notification_prefs['email_community'] = $email_community;
        $notification_prefs['email_marketing'] = $email_marketing;
        $notification_prefs['push_events'] = $push_events;
        $notification_prefs['push_appointments'] = $push_appointments;
        $notification_prefs['push_community'] = $push_community;
        $notification_prefs['push_marketing'] = $push_marketing;
    } catch (PDOException $e) {
        $notification_error_message = "Une erreur est survenue lors de la mise à jour des préférences de notification: " . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = :user_id");
    $stmt->execute(['user_id' => $employee_id]);
    $stored_password = $stmt->fetchColumn();
    
    if (!password_verify($current_password, $stored_password)) {
        $password_error_message = "Le mot de passe actuel est incorrect.";
    } elseif ($new_password !== $confirm_password) {
        $password_error_message = "Les nouveaux mots de passe ne correspondent pas.";
    } elseif (strlen($new_password) < 8) {
        $password_error_message = "Le nouveau mot de passe doit contenir au moins 8 caractères.";
    } else {

        try {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            $stmt = $pdo->prepare("
                UPDATE users 
                SET password = :password 
                WHERE id = :user_id
            ");
            
            $stmt->execute([
                'password' => $hashed_password,
                'user_id' => $employee_id
            ]);
            
            $password_success_message = "Votre mot de passe a été changé avec succès.";
        } catch (PDOException $e) {
            $password_error_message = "Une erreur est survenue lors du changement de mot de passe: " . $e->getMessage();
        }
    }
}

include '../includes/header.php';
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header">
                    <h4>Mon profil</h4>
                </div>
                <div class="card-body">
                    <ul class="nav nav-tabs" id="profileTabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="info-tab" data-toggle="tab" href="#info" role="tab" aria-controls="info" aria-selected="true">Informations personnelles</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="notifications-tab" data-toggle="tab" href="#notifications" role="tab" aria-controls="notifications" aria-selected="false">Préférences de notification</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="password-tab" data-toggle="tab" href="#password" role="tab" aria-controls="password" aria-selected="false">Changer le mot de passe</a>
                        </li>
                    </ul>
                    
                    <div class="tab-content mt-3" id="profileTabsContent">
                        <div class="tab-pane fade show active" id="info" role="tabpanel" aria-labelledby="info-tab">
                            <?php if (isset($success_message)): ?>
                                <div class="alert alert-success"><?php echo $success_message; ?></div>
                            <?php endif; ?>
                            
                            <?php if (isset($error_message)): ?>
                                <div class="alert alert-danger"><?php echo $error_message; ?></div>
                            <?php endif; ?>
                            
                            <div class="row mb-4">
                                <div class="col-md-4">
                                    <div class="text-center">
                                        <img src="../assets/img/avatar-placeholder.png" alt="Photo de profil" class="img-fluid rounded-circle mb-3" style="max-width: 150px;">
                                        <h5><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></h5>
                                        <p class="text-muted"><?php echo htmlspecialchars($user['email']); ?></p>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h5>Informations de base</h5>
                                    <p><strong>Entreprise:</strong> <?php echo htmlspecialchars($user['company_name']); ?></p>
                                    <p><strong>Date de naissance:</strong> <?php echo $user['birthdate'] ? date('d/m/Y', strtotime($user['birthdate'])) : 'Non renseignée'; ?></p>
                                    <p><strong>Genre:</strong> <?php echo $user['gender'] === 'M' ? 'Homme' : ($user['gender'] === 'F' ? 'Femme' : 'Non renseigné'); ?></p>
                                    
                                    <h5 class="mt-4">Modifier mes informations</h5>
                                    <form method="post" action="">
                                        <div class="form-group">
                                            <label for="phone">Téléphone</label>
                                            <input type="tel" name="phone" id="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone']); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="address">Adresse</label>
                                            <input type="text" name="address" id="address" class="form-control" value="<?php echo htmlspecialchars($user['address']); ?>">
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="postal_code">Code postal</label>
                                                    <input type="text" name="postal_code" id="postal_code" class="form-control" value="<?php echo htmlspecialchars($user['postal_code']); ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="city">Ville</label>
                                                    <input type="text" name="city" id="city" class="form-control" value="<?php echo htmlspecialchars($user['city']); ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <button type="submit" name="update_profile" class="btn btn-primary">Mettre à jour</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Onglet Préférences de notification -->
                        <div class="tab-pane fade" id="notifications" role="tabpanel" aria-labelledby="notifications-tab">
                            <?php if (isset($notification_success_message)): ?>
                                <div class="alert alert-success"><?php echo $notification_success_message; ?></div>
                            <?php endif; ?>
                            
                            <?php if (isset($notification_error_message)): ?>
                                <div class="alert alert-danger"><?php echo $notification_error_message; ?></div>
                            <?php endif; ?>
                            
                            <form method="post" action="">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h5>Notifications par e-mail</h5>
                                        <div class="form-group form-check">
                                            <input type="checkbox" name="email_events" id="email_events" class="form-check-input" <?php echo $notification_prefs['email_events'] ? 'checked' : ''; ?>>
                                            <label for="email_events" class="form-check-label">Événements et activités</label>
                                        </div>
                                        <div class="form-group form-check">
                                            <input type="checkbox" name="email_appointments" id="email_appointments" class="form-check-input" <?php echo $notification_prefs['email_appointments'] ? 'checked' : ''; ?>>
                                            <label for="email_appointments" class="form-check-label">Rendez-vous médicaux</label>
                                        </div>
                                        <div class="form-group form-check">
                                            <input type="checkbox" name="email_community" id="email_community" class="form-check-input" <?php echo $notification_prefs['email_community'] ? 'checked' : ''; ?>>
                                            <label for="email_community" class="form-check-label">Activités des communautés</label>
                                        </div>
                                        <div class="form-group form-check">
                                            <input type="checkbox" name="email_marketing" id="email_marketing" class="form-check-input" <?php echo $notification_prefs['email_marketing'] ? 'checked' : ''; ?>>
                                            <label for="email_marketing" class="form-check-label">Offres et nouveautés</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <h5>Notifications push</h5>
                                        <div class="form-group form-check">
                                            <input type="checkbox" name="push_events" id="push_events" class="form-check-input" <?php echo $notification_prefs['push_events'] ? 'checked' : ''; ?>>
                                            <label for="push_events" class="form-check-label">Événements et activités</label>
                                        </div>
                                        <div class="form-group form-check">
                                            <input type="checkbox" name="push_appointments" id="push_appointments" class="form-check-input" <?php echo $notification_prefs['push_appointments'] ? 'checked' : ''; ?>>
                                            <label for="push_appointments" class="form-check-label">Rendez-vous médicaux</label>
                                        </div>
                                        <div class="form-group form-check">
                                            <input type="checkbox" name="push_community" id="push_community" class="form-check-input" <?php echo $notification_prefs['push_community'] ? 'checked' : ''; ?>>
                                            <label for="push_community" class="form-check-label">Activités des communautés</label>
                                        </div>
                                        <div class="form-group form-check">
                                            <input type="checkbox" name="push_marketing" id="push_marketing" class="form-check-input" <?php echo $notification_prefs['push_marketing'] ? 'checked' : ''; ?>>
                                            <label for="push_marketing" class="form-check-label">Offres et nouveautés</label>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" name="update_notifications" class="btn btn-primary">Enregistrer les préférences</button>
                            </form>
                        </div>

                        <div class="tab-pane fade" id="password" role="tabpanel" aria-labelledby="password-tab">
                            <?php if (isset($password_success_message)): ?>
                                <div class="alert alert-success"><?php echo $password_success_message; ?></div>
                            <?php endif; ?>
                            
                            <?php if (isset($password_error_message)): ?>
                                <div class="alert alert-danger"><?php echo $password_error_message; ?></div>
                            <?php endif; ?>
                            
                            <form method="post" action="">
                                <div class="form-group">
                                    <label for="current_password">Mot de passe actuel</label>
                                    <input type="password" name="current_password" id="current_password" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="new_password">Nouveau mot de passe</label>
                                    <input type="password" name="new_password" id="new_password" class="form-control" required>
                                    <small class="form-text text-muted">Le mot de passe doit contenir au moins 8 caractères.</small>
                                </div>
                                <div class="form-group">
                                    <label for="confirm_password">Confirmer le nouveau mot de passe</label>
                                    <input type="password" name="confirm_password" id="confirm_password" class="form-control" required>
                                </div>
                                <button type="submit" name="change_password" class="btn btn-primary">Changer le mot de passe</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>