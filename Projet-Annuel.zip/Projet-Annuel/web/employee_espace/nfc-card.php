<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'employee') {
    header('Location: ../login.php');
    exit;
}

$employee_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT * FROM nfc_cards
    WHERE user_id = :user_id
");
$stmt->execute(['user_id' => $employee_id]);
$nfc_card = $stmt->fetch(PDO::FETCH_ASSOC);

$access_logs = [];
if ($nfc_card) {
    $stmt = $pdo->prepare("
        SELECT nal.* 
        FROM nfc_access_logs nal
        WHERE nal.card_id = :card_id
        ORDER BY nal.access_datetime DESC
        LIMIT 20
    ");
    $stmt->execute(['card_id' => $nfc_card['id']]);
    $access_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_new_card'])) {
    try {

        if ($nfc_card) {
            $stmt = $pdo->prepare("
                UPDATE nfc_cards
                SET is_active = 0
                WHERE id = :card_id
            ");
            $stmt->execute(['card_id' => $nfc_card['id']]);
        }
        
        $card_uid = bin2hex(random_bytes(8)); 
        
        $stmt = $pdo->prepare("
            INSERT INTO nfc_cards (user_id, card_uid, is_active, issued_date)
            VALUES (:user_id, :card_uid, 1, CURDATE())
        ");
        
        $stmt->execute([
            'user_id' => $employee_id,
            'card_uid' => $card_uid
        ]);
        
        $success_message = "Votre demande de nouvelle carte NFC a été enregistrée. Vous serez notifié lorsqu'elle sera prête à être récupérée.";
        
        header('Location: nfc-card.php');
        exit;
    } catch (PDOException $e) {
        $error_message = "Une erreur est survenue lors de la demande de nouvelle carte: " . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deactivate_card'])) {
    try {
        $stmt = $pdo->prepare("
            UPDATE nfc_cards
            SET is_active = 0
            WHERE id = :card_id AND user_id = :user_id
        ");
        
        $stmt->execute([
            'card_id' => $_POST['card_id'],
            'user_id' => $employee_id
        ]);
        
        $success_message = "Votre carte NFC a été désactivée avec succès.";
        
        header('Location: nfc-card.php');
        exit;
    } catch (PDOException $e) {
        $error_message = "Une erreur est survenue lors de la désactivation de la carte: " . $e->getMessage();
    }
}

include '../includes/header.php';
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header">
                    <h4>Ma carte NFC</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($success_message)): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    
                    <?php if ($nfc_card && $nfc_card['is_active']): ?>
                        <div class="alert alert-info">
                            Votre carte NFC est active et peut être utilisée pour accéder aux locaux de BusinessCare et aux événements.
                        </div>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Informations de la carte</h5>
                                        <p><strong>Numéro de carte:</strong> <?php echo htmlspecialchars(substr($nfc_card['card_uid'], 0, 4) . '...' . substr($nfc_card['card_uid'], -4)); ?></p>
                                        <p><strong>Date d'émission:</strong> <?php echo date('d/m/Y', strtotime($nfc_card['issued_date'])); ?></p>
                                        <p><strong>Statut:</strong> <span class="badge badge-success">Active</span></p>
                                        
                                        <form method="post" action="" onsubmit="return confirm('Êtes-vous sûr de vouloir désactiver votre carte NFC? Vous ne pourrez plus l\'utiliser pour accéder aux locaux.');">
                                            <input type="hidden" name="card_id" value="<?php echo $nfc_card['id']; ?>">
                                            <button type="submit" name="deactivate_card" class="btn btn-danger btn-sm">Signaler perte / Désactiver</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">Carte virtuelle</h5>
                                        <div class="p-3 border rounded mb-3" style="background-color: #f8f9fa;">
                                            <img src="../assets/img/nfc-logo.png" alt="Logo NFC" class="img-fluid mb-2" style="max-height: 50px;">
                                            <h5>BusinessCare</h5>
                                            <p class="mb-0">Carte d'accès</p>
                                            <hr>
                                            <p class="mb-0"><strong>ID: </strong><?php echo htmlspecialchars(substr($nfc_card['card_uid'], 0, 4) . '...' . substr($nfc_card['card_uid'], -4)); ?></p>
                                            <p class="mb-0"><strong>Date: </strong><?php echo date('d/m/Y', strtotime($nfc_card['issued_date'])); ?></p>
                                        </div>
                                        <small class="text-muted">Cette carte virtuelle ne remplace pas votre carte physique.</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <?php if (!empty($access_logs)): ?>
                            <h5>Historique des accès récents</h5>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Date et heure</th>
                                            <th>Localisation</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($access_logs as $log): ?>
                                            <tr>
                                                <td><?php echo date('d/m/Y H:i', strtotime($log['access_datetime'])); ?></td>
                                                <td><?php echo htmlspecialchars($log['location']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                        
                    <?php elseif ($nfc_card && !$nfc_card['is_active']): ?>
                        <div class="alert alert-warning">
                            Votre carte NFC a été désactivée. Si vous avez besoin d'une nouvelle carte, veuillez faire une demande ci-dessous.
                        </div>
                        
                        <form method="post" action="">
                            <button type="submit" name="request_new_card" class="btn btn-primary">Demander une nouvelle carte</button>
                        </form>
                        
                    <?php else: ?>
                        <div class="alert alert-info">
                            Vous n'avez pas encore de carte NFC. Cette carte vous permettra d'accéder aux locaux de BusinessCare et aux événements.
                        </div>
                        
                        <form method="post" action="">
                            <button type="submit" name="request_new_card" class="btn btn-primary">Demander une carte NFC</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>