<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../pages/login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once '../utils/pdf_generator.php';
    
    $client = [
        'name' => $_POST['client_name'],
        'company' => $_POST['client_company'],
        'address' => $_POST['client_address'],
        'email' => $_POST['client_email'],
        'phone' => $_POST['client_phone']
    ];
    
    $quote = [
        'id' => 'Q-' . date('YmdHis'),
        'date' => date('d/m/Y'),
        'validity' => date('d/m/Y', strtotime('+30 days'))
    ];
    
    $items = [];
    $itemCount = count($_POST['item_description']);
    
    for ($i = 0; $i < $itemCount; $i++) {
        if (!empty($_POST['item_description'][$i])) {
            $items[] = [
                'description' => $_POST['item_description'][$i],
                'quantity' => $_POST['item_quantity'][$i],
                'price' => $_POST['item_price'][$i]
            ];
        }
    }
    
    $quoteData = [
        'client' => $client,
        'quote' => $quote,
        'items' => $items
    ];
    
    
    $stmt = $conn->prepare("INSERT INTO quotes (quote_id, user_id, client_name, client_company, client_email, client_phone, client_address, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("sisssss", $quote['id'], $_SESSION['user_id'], $client['name'], $client['company'], $client['email'], $client['phone'], $client['address']);
    $stmt->execute();
    $quoteId = $stmt->insert_id;
    
    $itemStmt = $conn->prepare("INSERT INTO quote_items (quote_id, description, quantity, price) VALUES (?, ?, ?, ?)");
    
    foreach ($items as $item) {
        $itemStmt->bind_param("isid", $quoteId, $item['description'], $item['quantity'], $item['price']);
        $itemStmt->execute();
    }
    
    $stmt->close();
    $itemStmt->close();
    $conn->close();
    
    generateQuotePDF($quoteData);
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Générer un devis - BusinessCare</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <?php include_once '../includes/header.php'; ?>
    
    <div class="container">
        <h1>Générer un devis</h1>
        
        <form action="generate_quote.php" method="post" id="quoteForm">
            <div class="section">
                <h2>Informations client</h2>
                
                <div class="form-group">
                    <label for="client_name">Nom du client</label>
                    <input type="text" id="client_name" name="client_name" required>
                </div>
                
                <div class="form-group">
                    <label for="client_company">Entreprise</label>
                    <input type="text" id="client_company" name="client_company" required>
                </div>
                
                <div class="form-group">
                    <label for="client_address">Adresse</label>
                    <textarea id="client_address" name="client_address" rows="3" required></textarea>
                </div>
                
                <div class="form-group">
                    <label for="client_email">Email</label>
                    <input type="email" id="client_email" name="client_email" required>
                </div>
                
                <div class="form-group">
                    <label for="client_phone">Téléphone</label>
                    <input type="tel" id="client_phone" name="client_phone" required>
                </div>
            </div>
            
            <div class="section">
                <h2>Articles</h2>
                
                <div id="items-container">
                    <div class="item">
                        <div class="form-group">
                            <label for="item_description_0">Description</label>
                            <input type="text" id="item_description_0" name="item_description[]" required>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="item_quantity_0">Quantité</label>
                                <input type="number" id="item_quantity_0" name="item_quantity[]" min="1" value="1" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="item_price_0">Prix unitaire (€)</label>
                                <input type="number" id="item_price_0" name="item_price[]" min="0" step="0.01" required>
                            </div>
                        </div>
                    </div>
                </div>
                
                <button type="button" id="addItem" class="btn btn-secondary">Ajouter un article</button>
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-primary">Générer le devis</button>
            </div>
        </form>
    </div>
    
    <?php include_once '../includes/footer.php'; ?>
    
    <script>

            document.getElementById('addItem').addEventListener('click', function() {
                const container = document.getElementById('items-container');
                const newItem = document.createElement('div');
                newItem.className = 'item';
                newItem.innerHTML = `
                    <hr>
                    <div class="form-group">
                        <label for="item_description_${itemCount}">Description</label>
                        <input type="text" id="item_description_${itemCount}" name="item_description[]" required>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="item_quantity_${itemCount}">Quantité</label>
                            <input type="number" id="item_quantity_${itemCount}" name="item_quantity[]" min="1" value="1" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="item_price_${itemCount}">Prix unitaire (€)</label>
                            <input type="number" id="item_price_${itemCount}" name="item_price[]" min="0" step="0.01" required>
                        </div>
                    </div>
                    <button type="button" class="btn btn-danger remove-item">Supprimer</button>
                `;
                container.appendChild(newItem);
                
                newItem.querySelector('.remove-item').addEventListener('click', function() {
                    container.removeChild(newItem);
                });
                
                itemCount++;
            });
    </script>
</body>
</html>