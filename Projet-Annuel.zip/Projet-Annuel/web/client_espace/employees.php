<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'company_admin') {
    header('Location: ../login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT company_id FROM users WHERE id = :user_id");
$stmt->execute(['user_id' => $admin_id]);
$company_id = $stmt->fetchColumn();

if (!$company_id) {
    $error_message = "Erreur: Vous n'êtes pas associé à une entreprise.";
} else {
    $stmt = $pdo->prepare("SELECT * FROM companies WHERE id = :company_id");
    $stmt->execute(['company_id' => $company_id]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $stmt = $pdo->prepare("
        SELECT u.*, 
               (SELECT COUNT(*) FROM event_registrations er JOIN events e ON er.event_id = e.id WHERE er.user_id = u.id AND e.start_datetime >= NOW()) as upcoming_events,
               (SELECT COUNT(*) FROM medical_appointments ma WHERE ma.user_id = u.id AND ma.appointment_datetime >= NOW()) as upcoming_appointments
        FROM users u
        WHERE u.company_id = :company_id AND u.role = 'employee'
        ORDER BY u.last_name, u.first_name
    ");
    $stmt->execute(['company_id' => $company_id]);
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_employee'])) {
        $first_name = trim($_POST['first_name']);
        $last_name = trim($_POST['last_name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $gender = $_POST['gender'];
        $birthdate = $_POST['birthdate'] ? $_POST['birthdate'] : null;
        
        $password = bin2hex(random_bytes(6));
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        try {
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("
                INSERT INTO users (first_name, last_name, email, phone, gender, birthdate, password, role, company_id, created_at)
                VALUES (:first_name, :last_name, :email, :phone, :gender, :birthdate, :password, 'employee', :company_id, NOW())
            ");
            
            $stmt->execute([
                'first_name' => $first_name,
                'last_name' => $last_name,
                'email' => $email,
                'phone' => $phone,
                'gender' => $gender,
                'birthdate' => $birthdate,
                'password' => $hashed_password,
                'company_id' => $company_id
            ]);
            
            $new_user_id = $pdo->lastInsertId();

            $stmt = $pdo->prepare("
                INSERT INTO notification_preferences (user_id, created_at)
                VALUES (:user_id, NOW())
            ");
            $stmt->execute(['user_id' => $new_user_id]);
            
            $pdo->commit();
            
            $success_message = "L'employé a été ajouté avec succès. Un e-mail avec ses identifiants de connexion a été envoyé à $email.";
            
            $new_employee = [
                'id' => $new_user_id,
                'first_name' => $first_name,
                'last_name' => $last_name,
                'email' => $email,
                'phone' => $phone,
                'gender' => $gender,
                'birthdate' => $birthdate,
                'is_active' => 1,
                'upcoming_events' => 0,
                'upcoming_appointments' => 0
            ];
            $employees[] = $new_employee;
            
            
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error_message = "Erreur lors de l'ajout de l'employé: " . $e->getMessage();
        }
    }
    

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_status'])) {
        $employee_id = $_POST['employee_id'];
        $current_status = $_POST['current_status'];
        $new_status = $current_status ? 0 : 1;
        
        try {
            $stmt = $pdo->prepare("
                UPDATE users 
                SET is_active = :is_active
                WHERE id = :employee_id AND company_id = :company_id
            ");
            
            $stmt->execute([
                'is_active' => $new_status,
                'employee_id' => $employee_id,
                'company_id' => $company_id
            ]);
            
            $status_success_message = "Le statut de l'employé a été mis à jour avec succès.";
            
            foreach ($employees as &$emp) {
                if ($emp['id'] == $employee_id) {
                    $emp['is_active'] = $new_status;
                    break;
                }
            }
            
        } catch (PDOException $e) {
            $status_error_message = "Erreur lors de la mise à jour du statut: " . $e->getMessage();
        }
    }
}

include '../includes/header.php';
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>Gestion des employés</h4>
                    <button class="btn btn-primary" data-toggle="modal" data-target="#addEmployeeModal">
                        <i class="fas fa-plus"></i> Ajouter un employé
                    </button>
                </div>
                <div class="card-body">
                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($success_message)): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($status_success_message)): ?>
                        <div class="alert alert-success"><?php echo $status_success_message; ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($status_error_message)): ?>
                        <div class="alert alert-danger"><?php echo $status_error_message; ?></div>
                    <?php endif; ?>
                    
                    <?php if (!empty($employees)): ?>
                        <div class="table-responsive">
                            <table class="table table-striped" id="employeesTable">
                                <thead>
                                    <tr>
                                        <th>Nom</th>
                                        <th>Email</th>
                                        <th>Téléphone</th>
                                        <th>Statut</th>
                                        <th>Événements à venir</th>
                                        <th>RDV médicaux</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($employees as $employee): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></td>
                                            <td><?php echo htmlspecialchars($employee['email']); ?></td>
                                            <td><?php echo htmlspecialchars($employee['phone'] ?: '-'); ?></td>
                                            <td>
                                                <?php if ($employee['is_active']): ?>
                                                    <span class="badge badge-success">Actif</span>
                                                <?php else: ?>
                                                    <span class="badge badge-danger">Inactif</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo $employee['upcoming_events']; ?></td>
                                            <td><?php echo $employee['upcoming_appointments']; ?></td>
                                            <td>
                                                <a href="employee_detail.php?id=<?php echo $employee['id']; ?>" class="btn btn-sm btn-info">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                
                                                <form method="post" action="" class="d-inline">
                                                    <input type="hidden" name="employee_id" value="<?php echo $employee['id']; ?>">
                                                    <input type="hidden" name="current_status" value="<?php echo $employee['is_active']; ?>">
                                                    <button type="submit" name="toggle_status" class="btn btn-sm <?php echo $employee['is_active'] ? 'btn-warning' : 'btn-success'; ?>" onclick="return confirm('Êtes-vous sûr de vouloir <?php echo $employee['is_active'] ? 'désactiver' : 'réactiver'; ?> cet employé?')">
                                                        <i class="fas fa-<?php echo $employee['is_active'] ? 'ban' : 'check'; ?>"></i>
                                                    </button>
                                                </form>
                                                
                                                <button class="btn btn-sm btn-primary send-credentials-btn" data-employee-id="<?php echo $employee['id']; ?>" data-email="<?php echo htmlspecialchars($employee['email']); ?>">
                                                    <i class="fas fa-key"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">Aucun employé n'est enregistré pour votre entreprise.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addEmployeeModal" tabindex="-1" role="dialog" aria-labelledby="addEmployeeModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addEmployeeModalLabel">Ajouter un nouvel employé</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" action="">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="first_name">Prénom *</label>
                        <input type="text" name="first_name" id="first_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="last_name">Nom *</label>
                        <input type="text" name="last_name" id="last_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email *</label>
                        <input type="email" name="email" id="email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Téléphone</label>
                        <input type="tel" name="phone" id="phone" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="gender">Genre</label>
                        <select name="gender" id="gender" class="form-control">
                            <option value="">Non spécifié</option>
                            <option value="M">Homme</option>
                            <option value="F">Femme</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="birthdate">Date de naissance</label>
                        <input type="date" name="birthdate" id="birthdate" class="form-control">
                    </div>
                    <small class="form-text text-muted">Un mot de passe temporaire sera généré et envoyé à l'adresse email fournie.</small>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" name="add_employee" class="btn btn-primary">Ajouter</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#employeesTable').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/French.json"
            }
        });
        
        $('.send-credentials-btn').click(function() {
            var employeeId = $(this).data('employee-id');
            var email = $(this).data('email');
            
            if (confirm('Voulez-vous réinitialiser le mot de passe et envoyer de nouveaux identifiants à ' + email + '?')) {
                $.ajax({
                    url: 'reset_employee_password.php',
                    type: 'POST',
                    data: {
                        employee_id: employeeId
                    },
                    success: function(response) {
                        alert('Un nouveau mot de passe a été généré et envoyé à ' + email);
                    },
                    error: function() {
                        alert('Une erreur est survenue lors de la réinitialisation du mot de passe.');
                    }
                });
            }
        });
    });
</script>

<?php include '../includes/footer.php'; ?>