<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

$id = isset($_GET['id']) ? $_GET['id'] : null;

switch($method) {
    case 'GET':
        if($id) {
            getEvent($db, $id);
        } else {
            getEvents($db);
        }
        break;
    case 'POST':
        createEvent($db);
        break;
    case 'PUT':
        if($id) {
            updateEvent($db, $id);
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "ID événement manquant."));
        }
        break;
    case 'DELETE':
        if($id) {
            deleteEvent($db, $id);
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "ID événement manquant."));
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(array("message" => "Méthode non autorisée."));
        break;
}

function getEvents($db) {

    $page = isset($_GET['page']) ? $_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? $_GET['limit'] : 10;
    $start = ($page - 1) * $limit;
    
    $where = "WHERE 1";
    $params = array();
    
    if(isset($_GET['type_id']) && !empty($_GET['type_id'])) {
        $where .= " AND e.event_type_id = :type_id";
        $params[':type_id'] = $_GET['type_id'];
    }
    
    if(isset($_GET['provider_id']) && !empty($_GET['provider_id'])) {
        $where .= " AND e.provider_id = :provider_id";
        $params[':provider_id'] = $_GET['provider_id'];
    }
    
    if(isset($_GET['start_date']) && !empty($_GET['start_date'])) {
        $where .= " AND DATE(e.start_datetime) >= :start_date";
        $params[':start_date'] = $_GET['start_date'];
    }
    
    if(isset($_GET['end_date']) && !empty($_GET['end_date'])) {
        $where .= " AND DATE(e.end_datetime) <= :end_date";
        $params[':end_date'] = $_GET['end_date'];
    }
    
    if(isset($_GET['is_virtual'])) {
        $where .= " AND e.is_virtual = :is_virtual";
        $params[':is_virtual'] = $_GET['is_virtual'];
    }
    
    if(isset($_GET['future_only']) && $_GET['future_only'] == '1') {
        $where .= " AND e.start_datetime > NOW()";
    }
    
    $query = "SELECT e.*, et.name as event_type_name,
              (SELECT COUNT(*) FROM event_registrations WHERE event_id = e.id) as registration_count
              FROM events e 
              JOIN event_types et ON e.event_type_id = et.id 
              $where 
              ORDER BY e.start_datetime 
              LIMIT :start, :limit";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':start', $start, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    
    foreach($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $stmt->execute();
    $countQuery = "SELECT COUNT(*) as total FROM events e JOIN event_types et ON e.event_type_id = et.id $where";
    $countStmt = $db->prepare($countQuery);
    
    foreach($params as $key => $value) {
        $countStmt->bindValue($key, $value);
    }
    
    $countStmt->execute();
    $row = $countStmt->fetch(PDO::FETCH_ASSOC);
    $totalEvents = $row['total'];
    
    if($stmt->rowCount() > 0) {
        $events_arr = array();
        $events_arr["events"] = array();
        $events_arr["pagination"] = array(
            "total" => $totalEvents,
            "pages" => ceil($totalEvents / $limit),
            "current_page" => (int)$page,
            "per_page" => (int)$limit
        );
        
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $event_item = array(
                "id" => $row['id'],
                "title" => $row['title'],
                "description" => $row['description'],
                "event_type" => $row['event_type_name'],
                "location" => $row['location'],
                "is_virtual" => (bool)$row['is_virtual'],
                "max_participants" => $row['max_participants'],
                "registration_count" => $row['registration_count'],
                "start_datetime" => $row['start_datetime'],
                "end_datetime" => $row['end_datetime']
            );

            $event_item["is_full"] = ($row['max_participants'] > 0 && $row['registration_count'] >= $row['max_participants']);
            
            array_push($events_arr["events"], $event_item);
        }
        
        http_response_code(200);
        echo json_encode($events_arr);
    } else {
        http_response_code(200);
        echo json_encode(array("message" => "Aucun événement trouvé.", "events" => array()));
    }
}

function getEvent($db, $id) {
    $query = "SELECT e.*, et.name as event_type_name, et.is_medical,
              pp.id as provider_profile_id, u.first_name as provider_first_name, u.last_name as provider_last_name,
              (SELECT COUNT(*) FROM event_registrations WHERE event_id = e.id) as registration_count
              FROM events e 
              JOIN event_types et ON e.event_type_id = et.id 
              LEFT JOIN provider_profiles pp ON e.provider_id = pp.id 
              LEFT JOIN users u ON pp.user_id = u.id 
              WHERE e.id = :id";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    
    if($stmt->rowCount() > 0) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $event = array(
            "id" => $row['id'],
            "title" => $row['title'],
            "description" => $row['description'],
            "event_type" => array(
                "id" => $row['event_type_id'],
                "name" => $row['event_type_name'],
                "is_medical" => (bool)$row['is_medical']
            ),
            "location" => $row['location'],
            "is_virtual" => (bool)$row['is_virtual'],
            "max_participants" => $row['max_participants'],
            "registration_count" => $row['registration_count'],
            "start_datetime" => $row['start_datetime'],
            "end_datetime" => $row['end_datetime'],
            "created_at" => $row['created_at'],
            "updated_at" => $row['updated_at']
        );
        
        if($row['provider_id']) {
            $event["provider"] = array(
                "id" => $row['provider_profile_id'],
                "name" => $row['provider_first_name'] . ' ' . $row['provider_last_name']
            );
        } else {
            $event["provider"] = null;
        }

        $event["is_full"] = ($row['max_participants'] > 0 && $row['registration_count'] >= $row['max_participants']);
        

        if(!$row['is_medical']) {
            $regQuery = "SELECT er.id, er.user_id, er.status, er.registration_date,
                        u.first_name, u.last_name, u.email
                        FROM event_registrations er
                        JOIN users u ON er.user_id = u.id
                        WHERE er.event_id = :event_id
                        ORDER BY er.registration_date";
            
            $regStmt = $db->prepare($regQuery);
            $regStmt->bindParam(':event_id', $id);
            $regStmt->execute();
            
            $event["registrations"] = array();
            
            while($regRow = $regStmt->fetch(PDO::FETCH_ASSOC)) {
                $registration = array(
                    "id" => $regRow['id'],
                    "user" => array(
                        "id" => $regRow['user_id'],
                        "name" => $regRow['first_name'] . ' ' . $regRow['last_name'],
                        "email" => $regRow['email']
                    ),
                    "status" => $regRow['status'],
                    "registration_date" => $regRow['registration_date']
                );
                
                array_push($event["registrations"], $registration);
            }
        }
        
        http_response_code(200);
        echo json_encode($event);
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Événement non trouvé."));
    }
}

function createEvent($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if(
        !empty($data->title) && 
        !empty($data->event_type_id) && 
        !empty($data->start_datetime) && 
        !empty($data->end_datetime)
    ) {
        $query = "INSERT INTO events 
                (title, description, event_type_id, location, is_virtual, max_participants, 
                provider_id, start_datetime, end_datetime, created_at) 
                VALUES 
                (:title, :description, :event_type_id, :location, :is_virtual, :max_participants, 
                :provider_id, :start_datetime, :end_datetime, NOW())";
        
        $stmt = $db->prepare($query);
        

        $title = htmlspecialchars(strip_tags($data->title));
        $description = isset($data->description) ? htmlspecialchars(strip_tags($data->description)) : null;
        $location = isset($data->location) ? htmlspecialchars(strip_tags($data->location)) : null;
        $isVirtual = isset($data->is_virtual) ? $data->is_virtual : 0;
        $maxParticipants = isset($data->max_participants) ? $data->max_participants : null;
        $providerId = isset($data->provider_id) ? $data->provider_id : null;
        $startDatetime = $data->start_datetime;
        $endDatetime = $data->end_datetime;
        
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':event_type_id', $data->event_type_id);
        $stmt->bindParam(':location', $location);
        $stmt->bindParam(':is_virtual', $isVirtual);
        $stmt->bindParam(':max_participants', $maxParticipants);
        $stmt->bindParam(':provider_id', $providerId);
        $stmt->bindParam(':start_datetime', $startDatetime);
        $stmt->bindParam(':end_datetime', $endDatetime);
        
        if($stmt->execute()) {
            $event_id = $db->lastInsertId();
            
            http_response_code(201);
            echo json_encode(array(
                "message" => "Événement créé avec succès.",
                "id" => $event_id
            ));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Impossible de créer l'événement."));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Données incomplètes."));
    }
}

function updateEvent($db, $id) {
    $data = json_decode(file_get_contents("php://input"));
    
    $checkQuery = "SELECT id FROM events WHERE id = :id";
    $checkStmt = $db->prepare($checkQuery);
    $checkStmt->bindParam(':id', $id);
    $checkStmt->execute();
    
    if($checkStmt->rowCount() > 0) {
        $fields = array();
        $params = array();
        
        if(isset($data->title)) {
            $fields[] = "title = :title";
            $params[':title'] = htmlspecialchars(strip_tags($data->title));
        }
        
        if(isset($data->description)) {
            $fields[] = "description = :description";
            $params[':description'] = htmlspecialchars(strip_tags($data->description));
        }
        
        if(isset($data->event_type_id)) {
            $fields[] = "event_type_id = :event_type_id";
            $params[':event_type_id'] = $data->event_type_id;
        }
        
        if(isset($data->location)) {
            $fields[] = "location = :location";
            $params[':location'] = htmlspecialchars(strip_tags($data->location));
        }
        
        if(isset($data->is_virtual)) {
            $fields[] = "is_virtual = :is_virtual";
            $params[':is_virtual'] = $data->is_virtual ? 1 : 0;
        }
        
        if(isset($data->max_participants)) {
            $fields[] = "max_participants = :max_participants";
            $params[':max_participants'] = $data->max_participants;
        }
        
        if(isset($data->provider_id)) {
            $fields[] = "provider_id = :provider_id";
            $params[':provider_id'] = $data->provider_id;
        }
        
        if(isset($data->start_datetime)) {
            $fields[] = "start_datetime = :start_datetime";
            $params[':start_datetime'] = $data->start_datetime;
        }
        
        if(isset($data->end_datetime)) {
            $fields[] = "end_datetime = :end_datetime";
            $params[':end_datetime'] = $data->end_datetime;
        }
        
        if(count($fields) > 0) {
            $query = "UPDATE events SET " . implode(", ", $fields) . ", updated_at = NOW() WHERE id = :id";
            $params[':id'] = $id;
            
            $stmt = $db->prepare($query);
            
            foreach($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            if($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("message" => "Événement mis à jour avec succès."));
            } else {
                http_response_code(503);
                echo json_encode(array("message" => "Impossible de mettre à jour l'événement."));
            }
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "Aucune donnée fournie pour la mise à jour."));
        }
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Événement non trouvé."));
    }
}

function deleteEvent($db, $id) {

    $checkQuery = "SELECT id FROM events WHERE id = :id";
    $checkStmt = $db->prepare($checkQuery);
    $checkStmt->bindParam(':id', $id);
    $checkStmt->execute();
    
    if($checkStmt->rowCount() > 0) {

        $db->beginTransaction();
        
        try {
            $deleteRegsQuery = "DELETE FROM event_registrations WHERE event_id = :event_id";
            $deleteRegsStmt = $db->prepare($deleteRegsQuery);
            $deleteRegsStmt->bindParam(':event_id', $id);
            $deleteRegsStmt->execute();
            
            $query = "DELETE FROM events WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            
            $db->commit();
            
            http_response_code(200);
            echo json_encode(array("message" => "Événement supprimé avec succès."));
        } catch(Exception $e) {
            
            $db->rollBack();
            
            http_response_code(503);
            echo json_encode(array(
                "message" => "Impossible de supprimer l'événement.",
                "error" => $e->getMessage()
            ));
        }
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Événement non trouvé."));
    }
}
?>