<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$data = json_decode(file_get_contents("php://input"));

if(
    !isset($data->first_name) || 
    !isset($data->last_name) || 
    !isset($data->email) || 
    !isset($data->password) || 
    !isset($data->role)
) {
    http_response_code(400);
    echo json_encode(array("message" => "Données incomplètes."));
    exit();
}

$emailCheckQuery = "SELECT id FROM users WHERE email = :email";
$emailCheckStmt = $db->prepare($emailCheckQuery);
$emailCheckStmt->bindParam(':email', $data->email);
$emailCheckStmt->execute();

if($emailCheckStmt->rowCount() > 0) {
    http_response_code(400);
    echo json_encode(array("message" => "Cet email est déjà utilisé."));
    exit();
}

$allowedRoles = array('company_admin', 'employee', 'provider');
if(!in_array($data->role, $allowedRoles)) {
    http_response_code(400);
    echo json_encode(array("message" => "Rôle non valide."));
    exit();
}

$hashedPassword = password_hash($data->password, PASSWORD_DEFAULT);

$query = "INSERT INTO users 
          (first_name, last_name, email, phone, gender, birthdate, address, postal_code, city, password, role, company_id) 
          VALUES 
          (:first_name, :last_name, :email, :phone, :gender, :birthdate, :address, :postal_code, :city, :password, :role, :company_id)";

$stmt = $db->prepare($query);

$firstName = htmlspecialchars(strip_tags($data->first_name));
$lastName = htmlspecialchars(strip_tags($data->last_name));
$email = htmlspecialchars(strip_tags($data->email));
$phone = isset($data->phone) ? htmlspecialchars(strip_tags($data->phone)) : null;
$gender = isset($data->gender) ? htmlspecialchars(strip_tags($data->gender)) : null;
$birthdate = isset($data->birthdate) ? $data->birthdate : null;
$address = isset($data->address) ? htmlspecialchars(strip_tags($data->address)) : null;
$postalCode = isset($data->postal_code) ? htmlspecialchars(strip_tags($data->postal_code)) : null;
$city = isset($data->city) ? htmlspecialchars(strip_tags($data->city)) : null;
$companyId = isset($data->company_id) ? $data->company_id : null;

$stmt->bindParam(':first_name', $firstName);
$stmt->bindParam(':last_name', $lastName);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':phone', $phone);
$stmt->bindParam(':gender', $gender);
$stmt->bindParam(':birthdate', $birthdate);
$stmt->bindParam(':address', $address);
$stmt->bindParam(':postal_code', $postalCode);
$stmt->bindParam(':city', $city);
$stmt->bindParam(':password', $hashedPassword);
$stmt->bindParam(':role', $data->role);
$stmt->bindParam(':company_id', $companyId);

if($stmt->execute()) {
    $userId = $db->lastInsertId();
    
    $notifQuery = "INSERT INTO notification_preferences 
                  (user_id, email_events, email_appointments, email_community, email_marketing, 
                   push_events, push_appointments, push_community, push_marketing, created_at) 
                  VALUES 
                  (:user_id, 1, 1, 1, 0, 1, 1, 1, 0, NOW())";
    $notifStmt = $db->prepare($notifQuery);
    $notifStmt->bindParam(':user_id', $userId);
    $notifStmt->execute();
    

    if($data->role === 'provider' && isset($data->specialization_id)) {
        $providerQuery = "INSERT INTO provider_profiles (user_id, specialization_id, created_at) 
                         VALUES (:user_id, :specialization_id, NOW())";
        $providerStmt = $db->prepare($providerQuery);
        $providerStmt->bindParam(':user_id', $userId);
        $providerStmt->bindParam(':specialization_id', $data->specialization_id);
        $providerStmt->execute();
    }
    

    $logQuery = "INSERT INTO action_logs (user_id, action, description, ip_address, created_at) 
                VALUES (:user_id, 'register', :description, :ip, NOW())";
    $logStmt = $db->prepare($logQuery);
    $description = "Inscription réussie en tant que " . $data->role;
    $logStmt->bindParam(':user_id', $userId);
    $logStmt->bindParam(':description', $description);
    $logStmt->bindParam(':ip', $_SERVER['REMOTE_ADDR']);
    $logStmt->execute();
    
    http_response_code(201);
    echo json_encode(array(
        "message" => "Utilisateur créé avec succès.",
        "user_id" => $userId
    ));
} else {
    http_response_code(503);
    echo json_encode(array("message" => "Impossible de créer l'utilisateur."));
}
?>