<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

if($method == 'GET') {

    $category = isset($_GET['category']) ? $_GET['category'] : 'all';
    
    switch($category) {
        case 'companies':
            getCompaniesStats($db);
            break;
        case 'events':
            getEventsStats($db);
            break;
        case 'providers':
            getProvidersStats($db);
            break;
        case 'all':
        default:
            getAllStats($db);
            break;
    }
} else {
    http_response_code(405);
    echo json_encode(array("message" => "Méthode non autorisée."));
}

function getAllStats($db) {
    $stats = array(
        "companies" => getCompaniesStatsData($db),
        "events" => getEventsStatsData($db),
        "providers" => getProvidersStatsData($db)
    );
    
    http_response_code(200);
    echo json_encode($stats);
}

function getCompaniesStats($db) {
    $stats = getCompaniesStatsData($db);
    
    http_response_code(200);
    echo json_encode($stats);
}

function getEventsStats($db) {
    $stats = getEventsStatsData($db);
    
    http_response_code(200);
    echo json_encode($stats);
}

function getProvidersStats($db) {
    $stats = getProvidersStatsData($db);
    
    http_response_code(200);
    echo json_encode($stats);
}

function getCompaniesStatsData($db) {
    $stats = array();
    
    $query = "SELECT sp.name as plan_type, COUNT(s.id) as total 
              FROM subscriptions s 
              JOIN subscription_plans sp ON s.plan_id = sp.id 
              WHERE s.is_active = 1 
              GROUP BY sp.name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stats["subscription_distribution"] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $query = "SELECT c.id, c.name, 
             (SELECT COUNT(*) FROM users WHERE company_id = c.id) as employee_count 
             FROM companies c 
             ORDER BY employee_count DESC 
             LIMIT 5";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stats["top_companies_by_employees"] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $query = "SELECT YEAR(created_at) as year, MONTH(created_at) as month, 
              COUNT(*) as total_companies 
              FROM companies 
              GROUP BY YEAR(created_at), MONTH(created_at) 
              ORDER BY year DESC, month DESC 
              LIMIT 12";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stats["companies_by_month"] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $query = "SELECT COUNT(*) as total FROM companies";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats["total_companies"] = $row['total'];
    
    return $stats;
}

function getEventsStatsData($db) {
    $stats = array();
    
    $query = "SELECT et.name as event_type, COUNT(e.id) as total 
              FROM events e 
              JOIN event_types et ON e.event_type_id = et.id 
              GROUP BY et.name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stats["events_by_type"] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $query = "SELECT e.id, e.title, COUNT(er.id) as registration_count 
              FROM events e 
              JOIN event_registrations er ON e.id = er.event_id 
              GROUP BY e.id 
              ORDER BY registration_count DESC 
              LIMIT 5";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stats["top_events_by_registrations"] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $query = "SELECT et.name as event_type, 
              COUNT(CASE WHEN er.status = 'attended' THEN 1 END) as attended, 
              COUNT(er.id) as total_registrations,
              (COUNT(CASE WHEN er.status = 'attended' THEN 1 END) / COUNT(er.id)) * 100 as attendance_rate
              FROM events e 
              JOIN event_types et ON e.event_type_id = et.id 
              JOIN event_registrations er ON e.id = er.event_id 
              GROUP BY et.name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stats["attendance_by_type"] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $query = "SELECT COUNT(*) as total 
              FROM events 
              WHERE start_datetime > NOW()";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats["upcoming_events"] = $row['total'];
    
    $query = "SELECT YEAR(start_datetime) as year, MONTH(start_datetime) as month, 
              COUNT(*) as total_events 
              FROM events 
              GROUP BY YEAR(start_datetime), MONTH(start_datetime) 
              ORDER BY year DESC, month DESC 
              LIMIT 12";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stats["events_by_month"] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return $stats;
}

function getProvidersStatsData($db) {
    $stats = array();
    
    $query = "SELECT ps.name as specialization, COUNT(pp.id) as total 
              FROM provider_profiles pp 
              JOIN provider_specializations ps ON pp.specialization_id = ps.id 
              GROUP BY ps.name";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stats["providers_by_specialization"] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $query = "SELECT pp.id, CONCAT(u.first_name, ' ', u.last_name) as provider_name, 
              pp.rating, ps.name as specialization 
              FROM provider_profiles pp 
              JOIN users u ON pp.user_id = u.id 
              JOIN provider_specializations ps ON pp.specialization_id = ps.id 
              WHERE pp.rating > 0 
              ORDER BY pp.rating DESC 
              LIMIT 5";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stats["top_rated_providers"] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $query = "SELECT 
              CASE 
                WHEN hourly_rate < 50 THEN 'Moins de 50€' 
                WHEN hourly_rate BETWEEN 50 AND 75 THEN '50€-75€' 
                WHEN hourly_rate BETWEEN 76 AND 100 THEN '76€-100€' 
                ELSE 'Plus de 100€' 
              END as rate_range, 
              COUNT(*) as count 
              FROM provider_profiles 
              GROUP BY rate_range";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stats["hourly_rate_distribution"] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $query = "SELECT COUNT(*) as total FROM provider_profiles";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats["total_providers"] = $row['total'];
    
    $query = "SELECT 
              SUM(CASE WHEN is_verified = 1 THEN 1 ELSE 0 END) as verified,
              SUM(CASE WHEN is_verified = 0 THEN 1 ELSE 0 END) as not_verified
              FROM provider_profiles";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stats["verification_status"] = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return $stats;
}
?>