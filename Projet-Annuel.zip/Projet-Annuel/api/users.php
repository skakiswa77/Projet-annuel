<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

$id = isset($_GET['id']) ? $_GET['id'] : null;

switch($method) {
    case 'GET':
        if($id) {
            getUser($db, $id);
        } else {
            getUsers($db);
        }
        break;
    case 'PUT':
        if($id) {
            updateUser($db, $id);
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "ID utilisateur manquant."));
        }
        break;
    case 'DELETE':
        if($id) {
            deleteUser($db, $id);
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "ID utilisateur manquant."));
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(array("message" => "Méthode non autorisée."));
        break;
}

function getUsers($db) {

    $page = isset($_GET['page']) ? $_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? $_GET['limit'] : 10;
    $start = ($page - 1) * $limit;
    
    $where = "WHERE 1";
    $params = array();
    
    if(isset($_GET['role']) && !empty($_GET['role'])) {
        $where .= " AND role = :role";
        $params[':role'] = $_GET['role'];
    }
    
    if(isset($_GET['company_id']) && !empty($_GET['company_id'])) {
        $where .= " AND company_id = :company_id";
        $params[':company_id'] = $_GET['company_id'];
    }
    
    $query = "SELECT id, first_name, last_name, email, phone, role, company_id, is_active, last_login, created_at 
              FROM users $where ORDER BY last_name, first_name LIMIT :start, :limit";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':start', $start, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    
    foreach($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $stmt->execute();
    
    $countQuery = "SELECT COUNT(*) as total FROM users $where";
    $countStmt = $db->prepare($countQuery);
    
    foreach($params as $key => $value) {
        $countStmt->bindValue($key, $value);
    }
    
    $countStmt->execute();
    $row = $countStmt->fetch(PDO::FETCH_ASSOC);
    $totalUsers = $row['total'];
    
    if($stmt->rowCount() > 0) {
        $users_arr = array();
        $users_arr["users"] = array();
        $users_arr["pagination"] = array(
            "total" => $totalUsers,
            "pages" => ceil($totalUsers / $limit),
            "current_page" => (int)$page,
            "per_page" => (int)$limit
        );
        
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $user_item = array(
                "id" => $row['id'],
                "name" => $row['first_name'] . ' ' . $row['last_name'],
                "email" => $row['email'],
                "phone" => $row['phone'],
                "role" => $row['role'],
                "company_id" => $row['company_id'],
                "is_active" => (bool)$row['is_active'],
                "last_login" => $row['last_login'],
                "created_at" => $row['created_at']
            );
            array_push($users_arr["users"], $user_item);
        }
        
        http_response_code(200);
        echo json_encode($users_arr);
    } else {
        http_response_code(200);
        echo json_encode(array("message" => "Aucun utilisateur trouvé.", "users" => array()));
    }
}

function getUser($db, $id) {
    $query = "SELECT u.*, c.name as company_name 
              FROM users u 
              LEFT JOIN companies c ON u.company_id = c.id 
              WHERE u.id = :id";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    
    if($stmt->rowCount() > 0) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $user = array(
            "id" => $row['id'],
            "first_name" => $row['first_name'],
            "last_name" => $row['last_name'],
            "email" => $row['email'],
            "phone" => $row['phone'],
            "gender" => $row['gender'],
            "birthdate" => $row['birthdate'],
            "address" => $row['address'],
            "postal_code" => $row['postal_code'],
            "city" => $row['city'],
            "role" => $row['role'],
            "company" => array(
                "id" => $row['company_id'],
                "name" => $row['company_name']
            ),
            "is_active" => (bool)$row['is_active'],
            "last_login" => $row['last_login'],
            "created_at" => $row['created_at'],
            "updated_at" => $row['updated_at']
        );
        
        $notifQuery = "SELECT * FROM notification_preferences WHERE user_id = :user_id";
        $notifStmt = $db->prepare($notifQuery);
        $notifStmt->bindParam(':user_id', $id);
        $notifStmt->execute();
        
        if($notifStmt->rowCount() > 0) {
            $notifRow = $notifStmt->fetch(PDO::FETCH_ASSOC);
            $user["notification_preferences"] = array(
                "email_events" => (bool)$notifRow['email_events'],
                "email_appointments" => (bool)$notifRow['email_appointments'],
                "email_community" => (bool)$notifRow['email_community'],
                "email_marketing" => (bool)$notifRow['email_marketing'],
                "push_events" => (bool)$notifRow['push_events'],
                "push_appointments" => (bool)$notifRow['push_appointments'],
                "push_community" => (bool)$notifRow['push_community'],
                "push_marketing" => (bool)$notifRow['push_marketing']
            );
        }
        
        if($row['role'] === 'provider') {
            $providerQuery = "SELECT pp.*, ps.name as specialization 
                             FROM provider_profiles pp 
                             JOIN provider_specializations ps ON pp.specialization_id = ps.id 
                             WHERE pp.user_id = :user_id";
            $providerStmt = $db->prepare($providerQuery);
            $providerStmt->bindParam(':user_id', $id);
            $providerStmt->execute();
            
            if($providerStmt->rowCount() > 0) {
                $providerRow = $providerStmt->fetch(PDO::FETCH_ASSOC);
                $user["provider_profile"] = array(
                    "id" => $providerRow['id'],
                    "specialization" => $providerRow['specialization'],
                    "bio" => $providerRow['bio'],
                    "hourly_rate" => $providerRow['hourly_rate'],
                    "is_verified" => (bool)$providerRow['is_verified'],
                    "rating" => $providerRow['rating']
                );
            }
        }
        
        http_response_code(200);
        echo json_encode($user);
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Utilisateur non trouvé."));
    }
}

function updateUser($db, $id) {
    $data = json_decode(file_get_contents("php://input"));
    
    $checkQuery = "SELECT id FROM users WHERE id = :id";
    $checkStmt = $db->prepare($checkQuery);
    $checkStmt->bindParam(':id', $id);
    $checkStmt->execute();
    
    if($checkStmt->rowCount() > 0) {
        $fields = array();
        $params = array();
        
        if(isset($data->first_name)) {
            $fields[] = "first_name = :first_name";
            $params[':first_name'] = htmlspecialchars(strip_tags($data->first_name));
        }
        
        if(isset($data->last_name)) {
            $fields[] = "last_name = :last_name";
            $params[':last_name'] = htmlspecialchars(strip_tags($data->last_name));
        }
        
        if(isset($data->phone)) {
            $fields[] = "phone = :phone";
            $params[':phone'] = htmlspecialchars(strip_tags($data->phone));
        }
        
        if(isset($data->gender)) {
            $fields[] = "gender = :gender";
            $params[':gender'] = htmlspecialchars(strip_tags($data->gender));
        }
        
        if(isset($data->birthdate)) {
            $fields[] = "birthdate = :birthdate";
            $params[':birthdate'] = $data->birthdate;
        }
        
        if(isset($data->address)) {
            $fields[] = "address = :address";
            $params[':address'] = htmlspecialchars(strip_tags($data->address));
        }
        
        if(isset($data->postal_code)) {
            $fields[] = "postal_code = :postal_code";
            $params[':postal_code'] = htmlspecialchars(strip_tags($data->postal_code));
        }
        
        if(isset($data->city)) {
            $fields[] = "city = :city";
            $params[':city'] = htmlspecialchars(strip_tags($data->city));
        }
        
        if(isset($data->is_active)) {
            $fields[] = "is_active = :is_active";
            $params[':is_active'] = $data->is_active ? 1 : 0;
        }
        
        if(isset($data->company_id)) {
            $fields[] = "company_id = :company_id";
            $params[':company_id'] = $data->company_id;
        }
        
        if(count($fields) > 0) {
            $query = "UPDATE users SET " . implode(", ", $fields) . ", updated_at = NOW() WHERE id = :id";
            $params[':id'] = $id;
            
            $stmt = $db->prepare($query);
            
            foreach($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            if($stmt->execute()) {
                if(isset($data->notification_preferences)) {
                    $np = $data->notification_preferences;
                    $notifFields = array();
                    $notifParams = array();
                    
                    if(isset($np->email_events)) {
                        $notifFields[] = "email_events = :email_events";
                        $notifParams[':email_events'] = $np->email_events ? 1 : 0;
                    }
                    
                    if(isset($np->email_appointments)) {
                        $notifFields[] = "email_appointments = :email_appointments";
                        $notifParams[':email_appointments'] = $np->email_appointments ? 1 : 0;
                    }
                    
                    if(isset($np->email_community)) {
                        $notifFields[] = "email_community = :email_community";
                        $notifParams[':email_community'] = $np->email_community ? 1 : 0;
                    }
                    
                    if(isset($np->email_marketing)) {
                        $notifFields[] = "email_marketing = :email_marketing";
                        $notifParams[':email_marketing'] = $np->email_marketing ? 1 : 0;
                    }
                    
                    if(isset($np->push_events)) {
                        $notifFields[] = "push_events = :push_events";
                        $notifParams[':push_events'] = $np->push_events ? 1 : 0;
                    }
                    
                    if(isset($np->push_appointments)) {
                        $notifFields[] = "push_appointments = :push_appointments";
                        $notifParams[':push_appointments'] = $np->push_appointments ? 1 : 0;
                    }
                    
                    if(isset($np->push_community)) {
                        $notifFields[] = "push_community = :push_community";
                        $notifParams[':push_community'] = $np->push_community ? 1 : 0;
                    }
                    
                    if(isset($np->push_marketing)) {
                        $notifFields[] = "push_marketing = :push_marketing";
                        $notifParams[':push_marketing'] = $np->push_marketing ? 1 : 0;
                    }
                    
                    if(count($notifFields) > 0) {
                        $notifQuery = "UPDATE notification_preferences SET " . implode(", ", $notifFields) . ", updated_at = NOW() WHERE user_id = :user_id";
                        $notifParams[':user_id'] = $id;
                        
                        $notifStmt = $db->prepare($notifQuery);
                        
                        foreach($notifParams as $key => $value) {
                            $notifStmt->bindValue($key, $value);
                        }
                        
                        $notifStmt->execute();
                    }
                }
                
                if(isset($data->provider_profile)) {
                    $pp = $data->provider_profile;
                    $providerQuery = "UPDATE provider_profiles SET ";
                    $providerFields = array();
                    $providerParams = array();
                    
                    if(isset($pp->specialization_id)) {
                        $providerFields[] = "specialization_id = :specialization_id";
                        $providerParams[':specialization_id'] = $pp->specialization_id;
                    }
                    
                    if(isset($pp->bio)) {
                        $providerFields[] = "bio = :bio";
                        $providerParams[':bio'] = htmlspecialchars(strip_tags($pp->bio));
                    }
                    
                    if(isset($pp->hourly_rate)) {
                        $providerFields[] = "hourly_rate = :hourly_rate";
                        $providerParams[':hourly_rate'] = $pp->hourly_rate;
                    }
                    
                    if(isset($pp->is_verified)) {
                        $providerFields[] = "is_verified = :is_verified";
                        $providerParams[':is_verified'] = $pp->is_verified ? 1 : 0;
                    }
                    
                    if(count($providerFields) > 0) {
                        $providerQuery .= implode(", ", $providerFields) . ", updated_at = NOW() WHERE user_id = :user_id";
                        $providerParams[':user_id'] = $id;
                        
                        $providerStmt = $db->prepare($providerQuery);
                        
                        foreach($providerParams as $key => $value) {
                            $providerStmt->bindValue($key, $value);
                        }
                        
                        $providerStmt->execute();
                    }
                }
                
                http_response_code(200);
                echo json_encode(array("message" => "Utilisateur mis à jour avec succès."));
            } else {
                http_response_code(503);
                echo json_encode(array("message" => "Impossible de mettre à jour l'utilisateur."));
            }
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "Aucune donnée fournie pour la mise à jour."));
        }
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Utilisateur non trouvé."));
    }
}

function deleteUser($db, $id) {

   
    $checkQuery = "SELECT id FROM users WHERE id = :id";
    $checkStmt = $db->prepare($checkQuery);
    $checkStmt->bindParam(':id', $id);
    $checkStmt->execute();
    
    if($checkStmt->rowCount() > 0) {
      
        $query = "UPDATE users SET is_active = 0, updated_at = NOW() WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        
        if($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("message" => "Utilisateur désactivé avec succès."));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Impossible de désactiver l'utilisateur."));
        }
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Utilisateur non trouvé."));
    }
}
?>