<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

$id = isset($_GET['id']) ? $_GET['id'] : null;

switch($method) {
    case 'GET':
        if($id) {
            getProvider($db, $id);
        } else {
            getProviders($db);
        }
        break;
    case 'POST':
        createProvider($db);
        break;
    case 'PUT':
        if($id) {
            updateProvider($db, $id);
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "ID prestataire manquant."));
        }
        break;
    case 'DELETE':
        if($id) {
            deleteProvider($db, $id);
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "ID prestataire manquant."));
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(array("message" => "Méthode non autorisée."));
        break;
}


function getProviders($db) {
    $page = isset($_GET['page']) ? $_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? $_GET['limit'] : 10;
    $start = ($page - 1) * $limit;
    
    $where = "WHERE u.role = 'provider'";
    $params = array();
    
    if(isset($_GET['specialization_id']) && !empty($_GET['specialization_id'])) {
        $where .= " AND pp.specialization_id = :specialization_id";
        $params[':specialization_id'] = $_GET['specialization_id'];
    }
    
    if(isset($_GET['min_rating']) && !empty($_GET['min_rating'])) {
        $where .= " AND pp.rating >= :min_rating";
        $params[':min_rating'] = $_GET['min_rating'];
    }
    
    if(isset($_GET['is_verified']) && $_GET['is_verified'] == '1') {
        $where .= " AND pp.is_verified = 1";
    }
    
    $query = "SELECT pp.id, u.first_name, u.last_name, u.email, ps.name as specialization,
              pp.bio, pp.hourly_rate, pp.is_verified, pp.rating
              FROM provider_profiles pp 
              JOIN users u ON pp.user_id = u.id 
              JOIN provider_specializations ps ON pp.specialization_id = ps.id 
              $where 
              ORDER BY pp.rating DESC, u.last_name 
              LIMIT :start, :limit";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':start', $start, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    
    foreach($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $stmt->execute();
    
    $countQuery = "SELECT COUNT(*) as total 
                  FROM provider_profiles pp 
                  JOIN users u ON pp.user_id = u.id 
                  JOIN provider_specializations ps ON pp.specialization_id = ps.id 
                  $where";
    $countStmt = $db->prepare($countQuery);
    
    foreach($params as $key => $value) {
        $countStmt->bindValue($key, $value);
    }
    
    $countStmt->execute();
    $row = $countStmt->fetch(PDO::FETCH_ASSOC);
    $totalProviders = $row['total'];
    
    if($stmt->rowCount() > 0) {
        $providers_arr = array();
        $providers_arr["providers"] = array();
        $providers_arr["pagination"] = array(
            "total" => $totalProviders,
            "pages" => ceil($totalProviders / $limit),
            "current_page" => (int)$page,
            "per_page" => (int)$limit
        );
        
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $provider_item = array(
                "id" => $row['id'],
                "name" => $row['first_name'] . ' ' . $row['last_name'],
                "email" => $row['email'],
                "specialization" => $row['specialization'],
                "bio" => $row['bio'],
                "hourly_rate" => $row['hourly_rate'],
                "is_verified" => (bool)$row['is_verified'],
                "rating" => $row['rating']
            );
            
            array_push($providers_arr["providers"], $provider_item);
        }
        
        http_response_code(200);
        echo json_encode($providers_arr);
    } else {
        http_response_code(200);
        echo json_encode(array("message" => "Aucun prestataire trouvé.", "providers" => array()));
    }
}

function getProvider($db, $id) {
    $query = "SELECT pp.*, u.id as user_id, u.first_name, u.last_name, u.email, u.phone,
              ps.id as specialization_id, ps.name as specialization
              FROM provider_profiles pp 
              JOIN users u ON pp.user_id = u.id 
              JOIN provider_specializations ps ON pp.specialization_id = ps.id 
              WHERE pp.id = :id";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    
    if($stmt->rowCount() > 0) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $provider = array(
            "id" => $row['id'],
            "user" => array(
                "id" => $row['user_id'],
                "first_name" => $row['first_name'],
                "last_name" => $row['last_name'],
                "email" => $row['email'],
                "phone" => $row['phone']
            ),
            "specialization" => array(
                "id" => $row['specialization_id'],
                "name" => $row['specialization']
            ),
            "bio" => $row['bio'],
            "hourly_rate" => $row['hourly_rate'],
            "is_verified" => (bool)$row['is_verified'],
            "rating" => $row['rating'],
            "created_at" => $row['created_at'],
            "updated_at" => $row['updated_at']
        );
        
        $availQuery = "SELECT * FROM provider_availability 
                      WHERE provider_id = :provider_id 
                      ORDER BY day_of_week, start_time";
        $availStmt = $db->prepare($availQuery);
        $availStmt->bindParam(':provider_id', $id);
        $availStmt->execute();
        
        $provider["availability"] = array();
        
        while($availRow = $availStmt->fetch(PDO::FETCH_ASSOC)) {
            $availability = array(
                "id" => $availRow['id'],
                "day_of_week" => $availRow['day_of_week'],
                "start_time" => $availRow['start_time'],
                "end_time" => $availRow['end_time'],
                "is_available" => (bool)$availRow['is_available']
            );
            
            array_push($provider["availability"], $availability);
        }
        
        $reviewsQuery = "SELECT pr.*, u.first_name, u.last_name
                        FROM provider_reviews pr
                        JOIN users u ON pr.user_id = u.id
                        WHERE pr.provider_id = :provider_id
                        ORDER BY pr.created_at DESC
                        LIMIT 5";
        $reviewsStmt = $db->prepare($reviewsQuery);
        $reviewsStmt->bindParam(':provider_id', $row['user_id']);
        $reviewsStmt->execute();
        
        $provider["recent_reviews"] = array();
        
        while($reviewRow = $reviewsStmt->fetch(PDO::FETCH_ASSOC)) {
            $review = array(
                "id" => $reviewRow['id'],
                "rating" => $reviewRow['rating'],
                "comment" => $reviewRow['comment'],
                "reviewer" => $reviewRow['first_name'] . ' ' . $reviewRow['last_name'],
                "created_at" => $reviewRow['created_at']
            );
            
            array_push($provider["recent_reviews"], $review);
        }
        
        $eventsQuery = "SELECT e.id, e.title, e.start_datetime, e.end_datetime, et.name as event_type_name,
                       (SELECT COUNT(*) FROM event_registrations WHERE event_id = e.id) as registration_count
                       FROM events e
                       JOIN event_types et ON e.event_type_id = et.id
                       WHERE e.provider_id = :provider_id AND e.start_datetime > NOW()
                       ORDER BY e.start_datetime
                       LIMIT 5";
        $eventsStmt = $db->prepare($eventsQuery);
        $eventsStmt->bindParam(':provider_id', $id);
        $eventsStmt->execute();
        
        $provider["upcoming_events"] = array();
        
        while($eventRow = $eventsStmt->fetch(PDO::FETCH_ASSOC)) {
            $event = array(
                "id" => $eventRow['id'],
                "title" => $eventRow['title'],
                "event_type" => $eventRow['event_type_name'],
                "start_datetime" => $eventRow['start_datetime'],
                "end_datetime" => $eventRow['end_datetime'],
                "registration_count" => $eventRow['registration_count']
            );
            
            array_push($provider["upcoming_events"], $event);
        }
        
        http_response_code(200);
        echo json_encode($provider);
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Prestataire non trouvé."));
    }
}

function createProvider($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if(
        !empty($data->user_id) && 
        !empty($data->specialization_id)
    ) {

        $userQuery = "SELECT id, role FROM users WHERE id = :id";
        $userStmt = $db->prepare($userQuery);
        $userStmt->bindParam(':id', $data->user_id);
        $userStmt->execute();
        
        if($userStmt->rowCount() > 0) {
            $userRow = $userStmt->fetch(PDO::FETCH_ASSOC);
 
            $checkQuery = "SELECT id FROM provider_profiles WHERE user_id = :user_id";
            $checkStmt = $db->prepare($checkQuery);
            $checkStmt->bindParam(':user_id', $data->user_id);
            $checkStmt->execute();
            
            if($checkStmt->rowCount() > 0) {
                http_response_code(400);
                echo json_encode(array("message" => "Cet utilisateur a déjà un profil prestataire."));
                return;
            }
            
            if($userRow['role'] != 'provider') {
                $updateRoleQuery = "UPDATE users SET role = 'provider' WHERE id = :id";
                $updateRoleStmt = $db->prepare($updateRoleQuery);
                $updateRoleStmt->bindParam(':id', $data->user_id);
                $updateRoleStmt->execute();
            }
            
            $query = "INSERT INTO provider_profiles 
                    (user_id, specialization_id, bio, hourly_rate, is_verified, created_at) 
                    VALUES 
                    (:user_id, :specialization_id, :bio, :hourly_rate, :is_verified, NOW())";
            
            $stmt = $db->prepare($query);
            
            $bio = isset($data->bio) ? htmlspecialchars(strip_tags($data->bio)) : null;
            $hourlyRate = isset($data->hourly_rate) ? $data->hourly_rate : 0;
            $isVerified = isset($data->is_verified) ? $data->is_verified : 0;
            
            $stmt->bindParam(':user_id', $data->user_id);
            $stmt->bindParam(':specialization_id', $data->specialization_id);
            $stmt->bindParam(':bio', $bio);
            $stmt->bindParam(':hourly_rate', $hourlyRate);
            $stmt->bindParam(':is_verified', $isVerified);
            
            if($stmt->execute()) {
                $provider_id = $db->lastInsertId();
                
                http_response_code(201);
                echo json_encode(array(
                    "message" => "Profil prestataire créé avec succès.",
                    "id" => $provider_id
                ));
            } else {
                http_response_code(503);
                echo json_encode(array("message" => "Impossible de créer le profil prestataire."));
            }
        } else {
            http_response_code(404);
            echo json_encode(array("message" => "Utilisateur non trouvé."));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Données incomplètes."));
    }
}

function updateProvider($db, $id) {
    $data = json_decode(file_get_contents("php://input"));
    
    $checkQuery = "SELECT id FROM provider_profiles WHERE id = :id";
    $checkStmt = $db->prepare($checkQuery);
    $checkStmt->bindParam(':id', $id);
    $checkStmt->execute();
    
    if($checkStmt->rowCount() > 0) {
        $fields = array();
        $params = array();
        
        if(isset($data->specialization_id)) {
            $fields[] = "specialization_id = :specialization_id";
            $params[':specialization_id'] = $data->specialization_id;
        }
        
        if(isset($data->bio)) {
            $fields[] = "bio = :bio";
            $params[':bio'] = htmlspecialchars(strip_tags($data->bio));
        }
        
        if(isset($data->hourly_rate)) {
            $fields[] = "hourly_rate = :hourly_rate";
            $params[':hourly_rate'] = $data->hourly_rate;
        }
        
        if(isset($data->is_verified)) {
            $fields[] = "is_verified = :is_verified";
            $params[':is_verified'] = $data->is_verified ? 1 : 0;
        }
        
        if(count($fields) > 0) {
            $query = "UPDATE provider_profiles SET " . implode(", ", $fields) . ", updated_at = NOW() WHERE id = :id";
            $params[':id'] = $id;
            
            $stmt = $db->prepare($query);
            foreach($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            if($stmt->execute()) {

                if(isset($data->availability) && is_array($data->availability)) {
                    $deleteAvailQuery = "DELETE FROM provider_availability WHERE provider_id = :provider_id";
                    $deleteAvailStmt = $db->prepare($deleteAvailQuery);
                    $deleteAvailStmt->bindParam(':provider_id', $id);
                    $deleteAvailStmt->execute();

                    foreach($data->availability as $avail) {
                        if(
                            isset($avail->day_of_week) && 
                            isset($avail->start_time) && 
                            isset($avail->end_time)
                        ) {
                            $insertAvailQuery = "INSERT INTO provider_availability 
                                              (provider_id, day_of_week, start_time, end_time, is_available) 
                                              VALUES 
                                              (:provider_id, :day_of_week, :start_time, :end_time, :is_available)";
                            
                            $insertAvailStmt = $db->prepare($insertAvailQuery);
                            
                            $isAvailable = isset($avail->is_available) ? $avail->is_available : 1;
                            
                            $insertAvailStmt->bindParam(':provider_id', $id);
                            $insertAvailStmt->bindParam(':day_of_week', $avail->day_of_week);
                            $insertAvailStmt->bindParam(':start_time', $avail->start_time);
                            $insertAvailStmt->bindParam(':end_time', $avail->end_time);
                            $insertAvailStmt->bindParam(':is_available', $isAvailable);
                            
                            $insertAvailStmt->execute();
                        }
                    }
                }
                
                http_response_code(200);
                echo json_encode(array("message" => "Profil prestataire mis à jour avec succès."));
            } else {
                http_response_code(503);
                echo json_encode(array("message" => "Impossible de mettre à jour le profil prestataire."));
            }
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "Aucune donnée fournie pour la mise à jour."));
        }
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Prestataire non trouvé."));
    }
}

function deleteProvider($db, $id) {

    $checkQuery = "SELECT user_id FROM provider_profiles WHERE id = :id";
    $checkStmt = $db->prepare($checkQuery);
    $checkStmt->bindParam(':id', $id);
    $checkStmt->execute();
    
    if($checkStmt->rowCount() > 0) {
        $row = $checkStmt->fetch(PDO::FETCH_ASSOC);
        $userId = $row['user_id'];
        
        $db->beginTransaction();
        
        try {
            $deleteAvailQuery = "DELETE FROM provider_availability WHERE provider_id = :provider_id";
            $deleteAvailStmt = $db->prepare($deleteAvailQuery);
            $deleteAvailStmt->bindParam(':provider_id', $id);
            $deleteAvailStmt->execute();
            
            $query = "DELETE FROM provider_profiles WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            
            $updateRoleQuery = "UPDATE users SET role = 'employee' WHERE id = :id";
            $updateRoleStmt = $db->prepare($updateRoleQuery);
            $updateRoleStmt->bindParam(':id', $userId);
            $updateRoleStmt->execute();

            $db->commit();
            
            http_response_code(200);
            echo json_encode(array("message" => "Profil prestataire supprimé avec succès."));
        } catch(Exception $e) {
           
            $db->rollBack();
            
            http_response_code(503);
            echo json_encode(array(
                "message" => "Impossible de supprimer le profil prestataire.",
                "error" => $e->getMessage()
            ));
        }
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Prestataire non trouvé."));
    }
}
?>