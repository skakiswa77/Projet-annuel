<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

$id = isset($_GET['id']) ? $_GET['id'] : null;

switch($method) {
    case 'GET':
        if($id) {
            getCompany($db, $id);
        } else {
            getCompanies($db);
        }
        break;
    case 'POST':
        createCompany($db);
        break;
    case 'PUT':
        if($id) {
            updateCompany($db, $id);
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "ID société manquant."));
        }
        break;
    case 'DELETE':
        if($id) {
            deleteCompany($db, $id);
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "ID société manquant."));
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(array("message" => "Méthode non autorisée."));
        break;
}


function getCompanies($db) {

    $page = isset($_GET['page']) ? $_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? $_GET['limit'] : 10;
    $start = ($page - 1) * $limit;
    

    $query = "SELECT c.*, 
              (SELECT COUNT(*) FROM users WHERE company_id = c.id) as employee_count 
              FROM companies c 
              ORDER BY c.name 
              LIMIT :start, :limit";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':start', $start, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    

    $countQuery = "SELECT COUNT(*) as total FROM companies";
    $countStmt = $db->prepare($countQuery);
    $countStmt->execute();
    $row = $countStmt->fetch(PDO::FETCH_ASSOC);
    $totalCompanies = $row['total'];
    

    if($stmt->rowCount() > 0) {
        $companies_arr = array();
        $companies_arr["companies"] = array();
        $companies_arr["pagination"] = array(
            "total" => $totalCompanies,
            "pages" => ceil($totalCompanies / $limit),
            "current_page" => (int)$page,
            "per_page" => (int)$limit
        );
        
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $company_item = array(
                "id" => $row['id'],
                "name" => $row['name'],
                "address" => $row['address'],
                "phone" => $row['phone'],
                "email" => $row['email'],
                "employee_count" => $row['employee_count'],
                "created_at" => $row['created_at']
            );
            array_push($companies_arr["companies"], $company_item);
        }
        
        http_response_code(200);
        echo json_encode($companies_arr);
    } else {
        http_response_code(200);
        echo json_encode(array("message" => "Aucune société trouvée.", "companies" => array()));
    }
}

function getCompany($db, $id) {
    $query = "SELECT c.*, 
              (SELECT COUNT(*) FROM users WHERE company_id = c.id) as employee_count 
              FROM companies c 
              WHERE c.id = :id";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    
    if($stmt->rowCount() > 0) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $company = array(
            "id" => $row['id'],
            "name" => $row['name'],
            "address" => $row['address'],
            "phone" => $row['phone'],
            "email" => $row['email'],
            "employee_count" => $row['employee_count'],
            "created_at" => $row['created_at'],
            "updated_at" => $row['updated_at']
        );

        $subQuery = "SELECT s.*, sp.name as plan_name 
                    FROM subscriptions s 
                    JOIN subscription_plans sp ON s.plan_id = sp.id 
                    WHERE s.company_id = :company_id 
                    ORDER BY s.start_date DESC";
        $subStmt = $db->prepare($subQuery);
        $subStmt->bindParam(':company_id', $id);
        $subStmt->execute();
        
        $company["subscriptions"] = array();
        
        while($subRow = $subStmt->fetch(PDO::FETCH_ASSOC)) {
            $subscription = array(
                "id" => $subRow['id'],
                "plan" => array(
                    "id" => $subRow['plan_id'],
                    "name" => $subRow['plan_name']
                ),
                "start_date" => $subRow['start_date'],
                "end_date" => $subRow['end_date'],
                "is_active" => (bool)$subRow['is_active']
            );
            array_push($company["subscriptions"], $subscription);
        }
        
  
        $invoiceQuery = "SELECT i.* 
                        FROM invoices i 
                        WHERE i.company_id = :company_id 
                        ORDER BY i.issue_date DESC 
                        LIMIT 10";
        $invoiceStmt = $db->prepare($invoiceQuery);
        $invoiceStmt->bindParam(':company_id', $id);
        $invoiceStmt->execute();
        
        $company["recent_invoices"] = array();
        
        while($invoiceRow = $invoiceStmt->fetch(PDO::FETCH_ASSOC)) {
            $invoice = array(
                "id" => $invoiceRow['id'],
                "invoice_number" => $invoiceRow['invoice_number'],
                "amount" => $invoiceRow['amount'],
                "issue_date" => $invoiceRow['issue_date'],
                "due_date" => $invoiceRow['due_date'],
                "status" => $invoiceRow['status']
            );
            array_push($company["recent_invoices"], $invoice);
        }
        
        http_response_code(200);
        echo json_encode($company);
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Société non trouvée."));
    }
}


function createCompany($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if(!empty($data->name) && !empty($data->email)) {
        $query = "INSERT INTO companies (name, address, phone, email, created_at) 
                 VALUES (:name, :address, :phone, :email, NOW())";
        
        $stmt = $db->prepare($query);
        

        $name = htmlspecialchars(strip_tags($data->name));
        $address = isset($data->address) ? htmlspecialchars(strip_tags($data->address)) : null;
        $phone = isset($data->phone) ? htmlspecialchars(strip_tags($data->phone)) : null;
        $email = htmlspecialchars(strip_tags($data->email));
        

        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':phone', $phone);
        $stmt->bindParam(':email', $email);
        
        $db->beginTransaction();
        
        try {
            if($stmt->execute()) {
                $company_id = $db->lastInsertId();
                
                if(isset($data->subscription) && !empty($data->subscription->plan_id)) {
                    $subQuery = "INSERT INTO subscriptions 
                                (company_id, plan_id, start_date, end_date, is_active) 
                                VALUES 
                                (:company_id, :plan_id, :start_date, :end_date, 1)";
                    
                    $subStmt = $db->prepare($subQuery);
                    
                    $planId = $data->subscription->plan_id;
                    $startDate = isset($data->subscription->start_date) ? $data->subscription->start_date : date('Y-m-d');
                    $endDate = isset($data->subscription->end_date) ? $data->subscription->end_date : date('Y-m-d', strtotime('+1 year'));
                    
                    $subStmt->bindParam(':company_id', $company_id);
                    $subStmt->bindParam(':plan_id', $planId);
                    $subStmt->bindParam(':start_date', $startDate);
                    $subStmt->bindParam(':end_date', $endDate);
                    
                    $subStmt->execute();
                }
                
                $db->commit();
                
                http_response_code(201);
                echo json_encode(array(
                    "message" => "Société créée avec succès.",
                    "id" => $company_id
                ));
            } else {
                throw new Exception("Erreur lors de la création de la société.");
            }
        } catch(Exception $e) {
            $db->rollBack();
            
            http_response_code(503);
            echo json_encode(array(
                "message" => "Impossible de créer la société.",
                "error" => $e->getMessage()
            ));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Données incomplètes."));
    }
}

function updateCompany($db, $id) {
    $data = json_decode(file_get_contents("php://input"));
    
    $checkQuery = "SELECT id FROM companies WHERE id = :id";
    $checkStmt = $db->prepare($checkQuery);
    $checkStmt->bindParam(':id', $id);
    $checkStmt->execute();
    
    if($checkStmt->rowCount() > 0) {
        $fields = array();
        $params = array();
        
        if(isset($data->name)) {
            $fields[] = "name = :name";
            $params[':name'] = htmlspecialchars(strip_tags($data->name));
        }
        
        if(isset($data->address)) {
            $fields[] = "address = :address";
            $params[':address'] = htmlspecialchars(strip_tags($data->address));
        }
        
        if(isset($data->phone)) {
            $fields[] = "phone = :phone";
            $params[':phone'] = htmlspecialchars(strip_tags($data->phone));
        }
        
        if(isset($data->email)) {
            $fields[] = "email = :email";
            $params[':email'] = htmlspecialchars(strip_tags($data->email));
        }
        
        if(count($fields) > 0) {
            $query = "UPDATE companies SET " . implode(", ", $fields) . ", updated_at = NOW() WHERE id = :id";
            $params[':id'] = $id;
            
            $stmt = $db->prepare($query);
            
            foreach($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            if($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("message" => "Société mise à jour avec succès."));
            } else {
                http_response_code(503);
                echo json_encode(array("message" => "Impossible de mettre à jour la société."));
            }
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "Aucune donnée fournie pour la mise à jour."));
        }
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Société non trouvée."));
    }
}

function deleteCompany($db, $id) {

    $checkQuery = "SELECT id FROM companies WHERE id = :id";
    $checkStmt = $db->prepare($checkQuery);
    $checkStmt->bindParam(':id', $id);
    $checkStmt->execute();
    
    if($checkStmt->rowCount() > 0) {
        $userQuery = "SELECT COUNT(*) as count FROM users WHERE company_id = :company_id";
        $userStmt = $db->prepare($userQuery);
        $userStmt->bindParam(':company_id', $id);
        $userStmt->execute();
        $userRow = $userStmt->fetch(PDO::FETCH_ASSOC);
        
        if($userRow['count'] > 0) {
            http_response_code(400);
            echo json_encode(array(
                "message" => "Impossible de supprimer la société car des utilisateurs y sont associés.",
                "user_count" => $userRow['count']
            ));
            return;
        }
        
        $query = "DELETE FROM companies WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        
        if($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("message" => "Société supprimée avec succès."));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Impossible de supprimer la société."));
        }
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Société non trouvée."));
    }
}
?>