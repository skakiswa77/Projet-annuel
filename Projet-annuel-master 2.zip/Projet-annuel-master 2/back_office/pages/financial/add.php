<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Finances</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>
<body></body>
</html>

<?php

require_once '../../composants/nav.php';


require_once '../../config/database.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $stmt = $pdo->prepare("INSERT INTO utilisateurs (nom, prenom, genre, adresse, code_postal, ville, telephone, email, password, niveau, created_at) 
                          VALUES (:nom, :prenom, :genre, :adresse, :code_postal, :ville, :telephone, :email, :password, :niveau,  NOW())");
    $stmt->execute([
        ':nom' => $_POST['nom'],
        ':prenom' => $_POST['prenom'],
        ':genre' => $_POST['genre'],
        ':adresse' => $_POST['adresse'],
        ':code_postal' => $_POST['code_postal'],
        ':ville' => $_POST['ville'],
        ':telephone' => $_POST['telephone'],
        ':email' => $_POST['email'],
        ':password' => $_POST['password'],
        ':niveau' => $_POST['niveau']
    ]);
    header("Location: index.php");
    exit();
}
?>
<h2>Ajouter un moyen de financement</h2>
<form method="POST">
    <input type="text" name="nom" placeholder="Nom" required><br>
    <input type="text" name="prenom" placeholder="Prénom" required><br>
    <div class="checkbox-group">
                <label>Homme<input type="checkbox" name="niveau" value="CLIENT"></label>
                <label>Femme<input type="checkbox" name="niveau" value="EMPLOYÉ"></label>
            </div>
    <textarea name="description" placeholder="Description"></textarea><br>
    <input type="date" name="date" required><br>
    <input type="text" name="location" placeholder="Lieu" required><br>
    <button type="submit">Ajouter</button>
</form>